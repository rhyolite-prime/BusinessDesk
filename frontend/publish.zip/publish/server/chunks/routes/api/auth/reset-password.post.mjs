import { d as defineEventHandler, r as readBody, e as getCookie } from '../../../nitro/nitro.mjs';
import { d as db, l as logAudit } from '../../../_/db.mjs';
import { a as authStore } from '../../../_/auth-store.mjs';
import { b as badRequest } from '../../../_/helpers.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const resetPassword_post = defineEventHandler(async (event) => {
  var _a, _b;
  const d = db();
  const body = await readBody(event);
  const token = getCookie(event, "tl_session");
  const session = token ? authStore().sessions.get(token) : void 0;
  const user = d.users.find((u) => {
    var _a2;
    return u.id === ((_a2 = session == null ? void 0 : session.userId) != null ? _a2 : d.currentUser.id);
  });
  if (!user) throw badRequest("Not signed in.");
  const st = authStore();
  const current = (_a = st.passwords.get(user.username)) != null ? _a : "demo1234";
  if (((_b = body.current) != null ? _b : "") !== current) throw badRequest("Current password is incorrect.");
  if (!body.next || body.next.length < 6) throw badRequest("New password must be at least 6 characters.");
  st.passwords.set(user.username, body.next);
  logAudit(d, "User", "PASSWORD_RESET", user.id, user.username, "Password changed");
  return { ok: true, message: "Password updated successfully." };
});

export { resetPassword_post as default };
//# sourceMappingURL=reset-password.post.mjs.map
