import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { d as db, l as logAudit } from '../../../_/db.mjs';
import { a as authStore } from '../../../_/auth-store.mjs';
import { b as badRequest } from '../../../_/helpers.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const login_post = defineEventHandler(async (event) => {
  var _a, _b;
  const d = db();
  const body = await readBody(event);
  const username = ((_a = body.username) != null ? _a : "").trim().toLowerCase();
  const password = (_b = body.password) != null ? _b : "";
  const user = d.users.find((u) => u.username.toLowerCase() === username);
  const pass = authStore().passwords.get(username);
  const demoPassword = pass != null ? pass : "demo1234";
  if (!user || password !== demoPassword) {
    logAudit(d, "Auth", "LOGIN", 0, username, "Invalid credentials", "failure");
    throw badRequest("Invalid username or password.");
  }
  if (user.status === "disabled") throw badRequest("This account has been disabled. Contact your administrator.");
  const challengeId = crypto.randomUUID();
  authStore().pendingLogin.set(challengeId, { username, createdAt: Date.now() });
  logAudit(d, "Auth", "LOGIN_STEP1", user.id, `${user.firstname} ${user.lastname}`, "Password OK \u2014 2FA challenge");
  return {
    challenge: "2fa-required",
    challengeId,
    username: user.username,
    displayName: `${user.firstname} ${user.lastname}`,
    message: "Password accepted \u2014 enter your authenticator code."
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
