import { d as defineEventHandler, e as getCookie, f as deleteCookie } from '../../../nitro/nitro.mjs';
import { a as authStore } from '../../../_/auth-store.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const logout_post = defineEventHandler((event) => {
  const token = getCookie(event, "tl_session");
  if (token) authStore().sessions.delete(token);
  deleteCookie(event, "tl_session", { path: "/" });
  deleteCookie(event, "tl_authed", { path: "/" });
  return { ok: true };
});

export { logout_post as default };
//# sourceMappingURL=logout.post.mjs.map
