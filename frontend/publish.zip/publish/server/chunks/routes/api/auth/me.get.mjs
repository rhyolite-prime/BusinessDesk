import { d as defineEventHandler, e as getCookie, s as setResponseStatus } from '../../../nitro/nitro.mjs';
import { a as authStore } from '../../../_/auth-store.mjs';
import { d as db } from '../../../_/db.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const me_get = defineEventHandler((event) => {
  var _a;
  const token = getCookie(event, "tl_session");
  const session = token ? authStore().sessions.get(token) : void 0;
  if (!session) {
    setResponseStatus(event, 401);
    return { authenticated: false, demo: false };
  }
  const d = db();
  const user = d.users.find((candidate) => candidate.id === session.userId);
  if (!user) {
    setResponseStatus(event, 401);
    return { authenticated: false, demo: false };
  }
  const office = d.offices.find((candidate) => candidate.id === user.officeId);
  return {
    authenticated: true,
    demo: true,
    accountId: "DEMO-01",
    id: user.id,
    username: user.username,
    name: `${user.firstname} ${user.lastname}`,
    firstname: user.firstname,
    lastname: user.lastname,
    email: user.email,
    roleNames: user.roleNames,
    officeId: user.officeId,
    officeName: (_a = office == null ? void 0 : office.name) != null ? _a : "",
    permissions: ["*"]
  };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
