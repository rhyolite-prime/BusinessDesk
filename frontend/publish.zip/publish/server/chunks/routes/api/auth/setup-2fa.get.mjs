import { d as defineEventHandler, g as getQuery } from '../../../nitro/nitro.mjs';
import { b as badRequest } from '../../../_/helpers.mjs';
import { a as authStore } from '../../../_/auth-store.mjs';
import { g as generateTotpSecret, o as otpauthUrl, c as currentTotp } from '../../../_/totp.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const setup2fa_get = defineEventHandler(async (event) => {
  var _a;
  const q = getQuery(event);
  const username = String((_a = q.username) != null ? _a : "").trim().toLowerCase();
  if (!username) throw badRequest("username required");
  const st = authStore();
  let secret = st.totp.get(username);
  if (!secret) {
    secret = generateTotpSecret();
    st.totp.set(username, secret);
  }
  const issuer = "BusinessDesk ERP";
  const url = otpauthUrl(secret, issuer, username);
  const QRCode = await import('qrcode');
  const qr = await QRCode.toDataURL(url, { width: 220, margin: 1, color: { dark: "#0C231C", light: "#FFFFFF" } });
  return {
    secret,
    otpauth: url,
    qr,
    issuer,
    demoCode: currentTotp(secret),
    demoCodeExpiresIn: 30 - Math.floor(Date.now() / 1e3) % 30
  };
});

export { setup2fa_get as default };
//# sourceMappingURL=setup-2fa.get.mjs.map
