import { d as defineEventHandler, r as readBody, h as setCookie } from '../../../nitro/nitro.mjs';
import { d as db, l as logAudit } from '../../../_/db.mjs';
import { a as authStore } from '../../../_/auth-store.mjs';
import { b as badRequest } from '../../../_/helpers.mjs';
import { g as generateTotpSecret, v as verifyTotp } from '../../../_/totp.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const verify2fa_post = defineEventHandler(async (event) => {
  var _a, _b;
  const d = db();
  const body = await readBody(event);
  const st = authStore();
  const pending = st.pendingLogin.get((_a = body.challengeId) != null ? _a : "");
  if (!pending) throw badRequest("Login session expired. Please sign in again.");
  if (Date.now() - pending.createdAt > 10 * 60 * 1e3) {
    st.pendingLogin.delete(body.challengeId);
    throw badRequest("Login session expired. Please sign in again.");
  }
  let secret = st.totp.get(pending.username);
  if (!secret) {
    secret = generateTotpSecret();
    st.totp.set(pending.username, secret);
  }
  if (!verifyTotp(secret, (_b = body.code) != null ? _b : "")) {
    logAudit(d, "Auth", "LOGIN_2FA", 0, pending.username, "Invalid authenticator code", "failure");
    throw badRequest("Invalid authenticator code. Please try again.");
  }
  const user = d.users.find((u) => u.username.toLowerCase() === pending.username);
  if (!user) throw badRequest("User no longer exists.");
  st.pendingLogin.delete(body.challengeId);
  const token = crypto.randomUUID();
  st.sessions.set(token, { userId: user.id, username: user.username, issuedAt: Date.now() });
  setCookie(event, "tl_session", token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 12
    // 12 hours
  });
  setCookie(event, "tl_authed", "1", {
    httpOnly: false,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 12
  });
  logAudit(d, "Auth", "LOGIN", user.id, `${user.firstname} ${user.lastname}`, "Signed in with 2FA");
  return {
    authenticated: true,
    user: { id: user.id, username: user.username, name: `${user.firstname} ${user.lastname}` }
  };
});

export { verify2fa_post as default };
//# sourceMappingURL=verify-2fa.post.mjs.map
