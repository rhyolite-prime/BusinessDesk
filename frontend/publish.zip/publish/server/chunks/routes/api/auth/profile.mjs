import { d as defineEventHandler, e as getCookie, r as readBody } from '../../../nitro/nitro.mjs';
import { d as db, l as logAudit } from '../../../_/db.mjs';
import { a as authStore } from '../../../_/auth-store.mjs';
import { b as badRequest } from '../../../_/helpers.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const profile = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const d = db();
  const token = getCookie(event, "tl_session");
  const session = token ? authStore().sessions.get(token) : void 0;
  const user = d.users.find((u) => {
    var _a2;
    return u.id === ((_a2 = session == null ? void 0 : session.userId) != null ? _a2 : d.currentUser.id);
  });
  if (!user) throw badRequest("Not signed in.");
  const office = d.offices.find((o) => o.id === user.officeId);
  if (event.method === "PUT") {
    const b = await readBody(event);
    user.firstname = (_a = b.firstname) != null ? _a : user.firstname;
    user.lastname = (_b = b.lastname) != null ? _b : user.lastname;
    user.email = (_c = b.email) != null ? _c : user.email;
    if (b.mobile) user.mobile = b.mobile;
    logAudit(d, "User", "PROFILE_UPDATE", user.id, user.username, "Profile updated");
  }
  return {
    id: user.id,
    username: user.username,
    name: `${user.firstname} ${user.lastname}`,
    firstname: user.firstname,
    lastname: user.lastname,
    email: user.email,
    mobile: (_d = user.mobile) != null ? _d : "",
    officeId: user.officeId,
    officeName: (_e = office == null ? void 0 : office.name) != null ? _e : "",
    roleNames: user.roleNames,
    hasTotp: authStore().totp.has(user.username)
  };
});

export { profile as default };
//# sourceMappingURL=profile.mjs.map
