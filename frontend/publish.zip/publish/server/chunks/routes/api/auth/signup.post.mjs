import { d as defineEventHandler, r as readBody } from '../../../nitro/nitro.mjs';
import { d as db, t as todayISO, l as logAudit } from '../../../_/db.mjs';
import { b as badRequest } from '../../../_/helpers.mjs';
import { a as authStore } from '../../../_/auth-store.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const signup_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const d = db();
  const b = await readBody(event);
  const institution = ((_a = b.institution) != null ? _a : "").trim();
  const fullname = ((_b = b.fullname) != null ? _b : "").trim();
  const email = ((_c = b.email) != null ? _c : "").trim().toLowerCase();
  const password = (_d = b.password) != null ? _d : "";
  if (!institution) throw badRequest("Institution name is required.");
  if (!fullname) throw badRequest("Your name is required.");
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw badRequest("A valid work email is required.");
  if (password.length < 8) throw badRequest("Password must be at least 8 characters.");
  if (!b.totpSecret) throw badRequest("2FA enrolment is required.");
  const username = email.split("@")[0].replace(/[^a-z0-9.]/g, ".");
  if (d.users.some((u) => u.email.toLowerCase() === email || u.username.toLowerCase() === username)) {
    throw badRequest("An account with this email already exists.");
  }
  const office = {
    id: Math.max(0, ...d.offices.map((o) => o.id)) + 1,
    name: `${institution} \u2014 Head Office`,
    parentId: null,
    openingDate: todayISO(),
    externalId: `OFF-${institution.slice(0, 4).toUpperCase()}-${Math.floor(Math.random() * 9e3 + 1e3)}`,
    status: "active"
  };
  d.offices.push(office);
  const [firstname, ...rest] = fullname.split(" ");
  const user = {
    id: Math.max(0, ...d.users.map((u) => u.id)) + 1,
    username,
    firstname: firstname || "Admin",
    lastname: rest.join(" ") || "User",
    email,
    officeId: office.id,
    roleNames: ["Super User"],
    status: "active",
    lastLogin: todayISO()
  };
  d.users.push(user);
  const st = authStore();
  st.passwords.set(username, password);
  st.totp.set(username, b.totpSecret);
  logAudit(d, "Tenant", "SIGNUP", office.id, institution, `Tenant provisioned for ${email} (admin: ${username})`);
  return {
    ok: true,
    username,
    institution,
    officeId: office.id,
    message: `${institution} provisioned. Sign in with ${username} and your new password.`
  };
});

export { signup_post as default };
//# sourceMappingURL=signup.post.mjs.map
