import { d as defineEventHandler, b as getRouterParam, c as createError, r as readBody, u as useRuntimeConfig, a as getHeader } from '../../../../nitro/nitro.mjs';
import { g as getDemoVoucher, s as saveDemoVoucher } from '../../../../_/ledger-voucher-demo.mjs';
import { r as requireBusinessDeskSession } from '../../../../_/auth.mjs';
import { n as normalizeVoucherInput } from '../../../../_/ledger-voucher-validation.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/auth-store.mjs';
import '../../../../_/setup-data.mjs';
import '../../../../_/organization-data.mjs';

const _id__put = defineEventHandler(async (event) => {
  const session = await requireBusinessDeskSession(event);
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "Voucher id is required." });
  const body = await readBody(event);
  const config = useRuntimeConfig(event);
  const baseUrl = String(config.ledgerApiBaseUrl || "").replace(/\/$/, "");
  if (baseUrl) {
    if (session.demo || !session.accessToken) {
      throw createError({ statusCode: 403, statusMessage: "Demo sign-in cannot access a configured ledger service." });
    }
    return await $fetch(`${baseUrl}/api/v1/ledger/vouchers/${encodeURIComponent(id)}`, {
      method: "PUT",
      body,
      headers: {
        authorization: `Bearer ${session.accessToken}`,
        "x-request-id": getHeader(event, "x-request-id") || crypto.randomUUID()
      }
    });
  }
  if (!config.public.demoMode) {
    throw createError({ statusCode: 503, statusMessage: "Ledger API is not configured", data: { code: "LEDGER_API_UNAVAILABLE" } });
  }
  const existing = getDemoVoucher(id);
  if (!existing) throw createError({ statusCode: 404, statusMessage: "Voucher not found." });
  if (existing.status !== "Draft") throw createError({ statusCode: 409, statusMessage: "Only draft vouchers can be edited." });
  if (existing.type !== body.type) throw createError({ statusCode: 400, statusMessage: "The voucher type cannot be changed." });
  const normalized = normalizeVoucherInput(body);
  const voucher = {
    ...normalized,
    id: existing.id,
    voucherNumber: existing.voucherNumber,
    batchNumber: existing.batchNumber,
    status: "Draft",
    preparer: existing.preparer,
    createdAt: existing.createdAt,
    updatedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  return saveDemoVoucher(voucher);
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
