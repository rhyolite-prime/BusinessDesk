import { d as defineEventHandler, r as readBody, c as createError, u as useRuntimeConfig, a as getHeader, s as setResponseStatus } from '../../../nitro/nitro.mjs';
import { f as formatLedgerAmount } from '../../../_/setup-data.mjs';
import { l as ledgerOrganizationalUnits } from '../../../_/organization-data.mjs';
import { n as normalizeJournalLineAmounts } from '../../../_/ledger-journal-amounts.mjs';
import { r as requireBusinessDeskSession, d as demoAccounts, g as getNextDemoJournalBatchNumber, c as demoJournals } from '../../../_/auth.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/auth-store.mjs';

function isRealDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = /* @__PURE__ */ new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
const journals_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  const session = await requireBusinessDeskSession(event);
  const body = await readBody(event);
  const description = String((_a = body == null ? void 0 : body.description) != null ? _a : "").trim();
  const batchDate = String((_b = body == null ? void 0 : body.batchDate) != null ? _b : "").trim();
  const sourceLines = Array.isArray(body == null ? void 0 : body.lines) ? body.lines : [];
  const isMultiCurrency = Boolean(body == null ? void 0 : body.isMultiCurrency) || sourceLines.some((line) => {
    var _a2;
    return String((_a2 = line == null ? void 0 : line.currencyCode) != null ? _a2 : "GHS").trim().toUpperCase() !== "GHS";
  });
  if (!description || description.length > 200 || !isRealDate(batchDate) || sourceLines.length < 2 || sourceLines.length > 1e3) {
    throw createError({ statusCode: 400, statusMessage: "Enter a description, valid date, and between two and 1000 journal lines." });
  }
  const normalizedLines = sourceLines.map((line, index) => {
    var _a2, _b2, _c2, _d2, _e2, _f, _g;
    const lineNumber = index + 1;
    const accountId = String((_a2 = line == null ? void 0 : line.accountId) != null ? _a2 : "").trim();
    const accountName = String((_b2 = line == null ? void 0 : line.accountName) != null ? _b2 : "").trim();
    const referenceNumber = String((_c2 = line == null ? void 0 : line.referenceNumber) != null ? _c2 : "").trim();
    const lineDescription = String((_d2 = line == null ? void 0 : line.description) != null ? _d2 : "").trim();
    const organizationUnitId2 = String((_e2 = line == null ? void 0 : line.organizationUnitId) != null ? _e2 : "").trim();
    const transactionDate = String((_f = line == null ? void 0 : line.transactionDate) != null ? _f : batchDate).trim();
    const chequeNumber = String((_g = line == null ? void 0 : line.chequeNumber) != null ? _g : "").trim();
    if (!accountId || accountId.length > 80 || !referenceNumber || referenceNumber.length > 80 || lineDescription.length > 300 || chequeNumber.length > 80 || organizationUnitId2.length > 80 || !isRealDate(transactionDate)) {
      throw createError({ statusCode: 400, statusMessage: `Line ${lineNumber} needs a reference, account, valid transaction date, and valid line details.` });
    }
    if (organizationUnitId2 && !ledgerOrganizationalUnits.some((unit) => unit.id === organizationUnitId2)) {
      throw createError({ statusCode: 400, statusMessage: `Line ${lineNumber}: select a valid organizational unit.` });
    }
    const amounts = normalizeJournalLineAmounts(line, lineNumber, isMultiCurrency);
    if (!amounts.value) throw createError({ statusCode: 400, statusMessage: amounts.errors.join(" ") });
    return {
      accountId,
      accountName,
      referenceNumber,
      description: lineDescription,
      organizationUnitId: organizationUnitId2,
      transactionDate,
      chequeNumber,
      ...amounts.value
    };
  });
  const config = useRuntimeConfig(event);
  const baseUrl = String(config.ledgerApiBaseUrl || "").replace(/\/$/, "");
  if (baseUrl) {
    if (session.demo || !session.accessToken) {
      throw createError({ statusCode: 403, statusMessage: "Demo sign-in cannot access a configured ledger service." });
    }
    return await $fetch(`${baseUrl}/api/v1/ledger/journals`, {
      method: "POST",
      body: {
        batchDate,
        description,
        isMultiCurrency,
        organizationUnitId: String((_c = body == null ? void 0 : body.organizationUnitId) != null ? _c : "").trim() || void 0,
        status: "draft",
        lines: normalizedLines.map((line) => ({
          accountId: line.accountId,
          accountName: line.accountName,
          referenceNumber: line.referenceNumber,
          description: line.description,
          organizationUnitId: line.organizationUnitId || void 0,
          transactionDate: line.transactionDate,
          chequeNumber: line.chequeNumber || void 0,
          currencyCode: line.currencyCode,
          currencyName: line.currencyName,
          exchangeRate: line.exchangeRate,
          foreignDebit: line.foreignDebit,
          foreignCredit: line.foreignCredit,
          debit: line.debit,
          credit: line.credit
        }))
      },
      headers: {
        authorization: `Bearer ${session.accessToken}`,
        "x-request-id": getHeader(event, "x-request-id") || crypto.randomUUID()
      }
    });
  }
  if (!config.public.demoMode) {
    throw createError({ statusCode: 503, statusMessage: "Ledger API is not configured", data: { code: "LEDGER_API_UNAVAILABLE" } });
  }
  for (const line of normalizedLines) {
    const account = demoAccounts.find((item) => item.id === line.accountId && item.status === "Active");
    if (!account) {
      throw createError({ statusCode: 400, statusMessage: "Select an active account from the chart of accounts for every journal line." });
    }
    if (account.currency.toUpperCase() !== line.currencyCode) {
      throw createError({ statusCode: 400, statusMessage: `Account ${account.accountNumber} is assigned to ${account.currency}; use its account currency on the journal line.` });
    }
  }
  const totalDebit = formatLedgerAmount(normalizedLines.reduce((sum, line) => sum + line.debitUnits, BigInt(0)));
  const totalCredit = formatLedgerAmount(normalizedLines.reduce((sum, line) => sum + line.creditUnits, BigInt(0)));
  const batchNumber = getNextDemoJournalBatchNumber(batchDate);
  const organizationUnitId = String((_d = body == null ? void 0 : body.organizationUnitId) != null ? _d : "").trim();
  if (organizationUnitId && !ledgerOrganizationalUnits.some((unit) => unit.id === organizationUnitId)) {
    throw createError({ statusCode: 400, statusMessage: "Select a valid organizational unit for the journal batch." });
  }
  const journalLines = normalizedLines.map((line) => {
    var _a2;
    const account = demoAccounts.find((item) => item.id === line.accountId);
    const unit = ledgerOrganizationalUnits.find((item) => item.id === line.organizationUnitId);
    return {
      id: `demo-${crypto.randomUUID()}`,
      accountId: line.accountId,
      accountNumber: account == null ? void 0 : account.accountNumber,
      accountName: (_a2 = account == null ? void 0 : account.name) != null ? _a2 : line.accountName,
      referenceNumber: line.referenceNumber,
      description: line.description,
      organizationUnitId: line.organizationUnitId || void 0,
      organizationUnitName: unit == null ? void 0 : unit.path,
      transactionDate: line.transactionDate,
      chequeNumber: line.chequeNumber || void 0,
      currencyCode: line.currencyCode,
      currencyName: line.currencyName,
      exchangeRate: line.exchangeRate,
      foreignDebit: line.foreignDebit,
      foreignCredit: line.foreignCredit,
      debit: line.debit,
      credit: line.credit
    };
  });
  const journal = {
    id: `demo-${crypto.randomUUID()}`,
    batchNumber,
    description,
    date: batchDate,
    source: "General journal",
    debit: totalDebit,
    credit: totalCredit,
    status: "Draft",
    preparer: session.username,
    organizationUnitName: (_e = ledgerOrganizationalUnits.find((unit) => unit.id === organizationUnitId)) == null ? void 0 : _e.path,
    isMultiCurrency,
    lineCount: journalLines.length,
    lines: journalLines
  };
  demoJournals.unshift(journal);
  setResponseStatus(event, 201);
  return journal;
});

export { journals_post as default };
//# sourceMappingURL=journals.post.mjs.map
