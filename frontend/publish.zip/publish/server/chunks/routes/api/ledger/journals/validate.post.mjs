import { d as defineEventHandler, r as readBody, u as useRuntimeConfig, c as createError, a as getHeader } from '../../../../nitro/nitro.mjs';
import { f as formatLedgerAmount } from '../../../../_/setup-data.mjs';
import { r as requireBusinessDeskSession, d as demoAccounts } from '../../../../_/auth.mjs';
import { n as normalizeJournalLineAmounts } from '../../../../_/ledger-journal-amounts.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/auth-store.mjs';

function isRealDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = /* @__PURE__ */ new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
const validate_post = defineEventHandler(async (event) => {
  var _a, _b;
  const session = await requireBusinessDeskSession(event);
  const body = await readBody(event);
  const lines = Array.isArray(body == null ? void 0 : body.lines) ? body.lines : [];
  const description = String((_a = body == null ? void 0 : body.description) != null ? _a : "").trim();
  const batchDate = String((_b = body == null ? void 0 : body.batchDate) != null ? _b : "").trim();
  const isMultiCurrency = Boolean(body == null ? void 0 : body.isMultiCurrency) || lines.some((line) => {
    var _a2;
    return String((_a2 = line == null ? void 0 : line.currencyCode) != null ? _a2 : "GHS").trim().toUpperCase() !== "GHS";
  });
  const errors = [];
  if (!description || description.length > 200) errors.push("Journal description is required and must not exceed 200 characters.");
  if (!isRealDate(batchDate)) errors.push("Journal date must be a real calendar date in YYYY-MM-DD format.");
  if (lines.length < 2) errors.push("A journal draft must contain at least two lines.");
  if (lines.length > 1e3) errors.push("A journal draft cannot contain more than 1000 lines.");
  const metadataErrors = [];
  lines.slice(0, 1e3).forEach((line, index) => {
    var _a2, _b2, _c, _d;
    const referenceNumber = String((_a2 = line == null ? void 0 : line.referenceNumber) != null ? _a2 : "").trim();
    const transactionDate = String((_b2 = line == null ? void 0 : line.transactionDate) != null ? _b2 : batchDate).trim();
    if (!referenceNumber || referenceNumber.length > 80) metadataErrors.push(`Line ${index + 1}: reference number is required and must not exceed 80 characters.`);
    if (!isRealDate(transactionDate)) metadataErrors.push(`Line ${index + 1}: transaction date must be a real calendar date in YYYY-MM-DD format.`);
    const accountId = String((_c = line == null ? void 0 : line.accountId) != null ? _c : "").trim();
    if (!accountId || accountId.length > 80) metadataErrors.push(`Line ${index + 1}: account is required and must not exceed 80 characters.`);
    if (String((_d = line == null ? void 0 : line.description) != null ? _d : "").length > 300) metadataErrors.push(`Line ${index + 1}: description must not exceed 300 characters.`);
  });
  errors.push(...metadataErrors);
  const amountResults = lines.slice(0, 1e3).map((line, index) => normalizeJournalLineAmounts(line, index + 1, isMultiCurrency));
  for (const result of amountResults) errors.push(...result.errors);
  if (errors.length) {
    return { valid: false, balanced: false, debitTotal: "0.000000", creditTotal: "0.000000", errors };
  }
  const normalizedLines = lines.slice(0, 1e3).map((line, index) => {
    var _a2;
    const amounts = (_a2 = amountResults[index]) == null ? void 0 : _a2.value;
    return {
      ...line,
      currencyCode: amounts.currencyCode,
      currencyName: amounts.currencyName,
      exchangeRate: amounts.exchangeRate,
      foreignDebit: amounts.foreignDebit,
      foreignCredit: amounts.foreignCredit,
      debit: amounts.debit,
      credit: amounts.credit
    };
  });
  const config = useRuntimeConfig(event);
  const baseUrl = String(config.ledgerApiBaseUrl || "").replace(/\/$/, "");
  if (baseUrl) {
    if (session.demo || !session.accessToken) {
      throw createError({ statusCode: 403, statusMessage: "Demo sign-in cannot access a configured ledger service." });
    }
    return await $fetch(`${baseUrl}/api/v1/ledger/journals/validate`, {
      method: "POST",
      body: { ...body, isMultiCurrency, lines: normalizedLines },
      headers: {
        authorization: `Bearer ${session.accessToken}`,
        "x-request-id": getHeader(event, "x-request-id") || crypto.randomUUID()
      }
    });
  }
  if (!config.public.demoMode) {
    throw createError({ statusCode: 503, statusMessage: "Ledger API is not configured", data: { code: "LEDGER_API_UNAVAILABLE" } });
  }
  for (const [index, line] of normalizedLines.entries()) {
    const account = demoAccounts.find((item) => item.id === line.accountId && item.status === "Active");
    if (!account) errors.push(`Line ${index + 1}: select an active account from the chart of accounts.`);
    else if (account.currency.toUpperCase() !== line.currencyCode) {
      errors.push(`Line ${index + 1}: account ${account.accountNumber} is assigned to ${account.currency}; use its account currency on the journal line.`);
    }
  }
  const debitUnits = amountResults.reduce((sum, result) => {
    var _a2, _b2;
    return sum + ((_b2 = (_a2 = result.value) == null ? void 0 : _a2.debitUnits) != null ? _b2 : BigInt(0));
  }, BigInt(0));
  const creditUnits = amountResults.reduce((sum, result) => {
    var _a2, _b2;
    return sum + ((_b2 = (_a2 = result.value) == null ? void 0 : _a2.creditUnits) != null ? _b2 : BigInt(0));
  }, BigInt(0));
  const valid = errors.length === 0;
  return {
    valid,
    balanced: valid && debitUnits === creditUnits,
    debitTotal: formatLedgerAmount(debitUnits),
    creditTotal: formatLedgerAmount(creditUnits),
    errors
  };
});

export { validate_post as default };
//# sourceMappingURL=validate.post.mjs.map
