import { d as defineEventHandler, g as getQuery } from '../../../nitro/nitro.mjs';
import { f as filterDemoAccounts } from '../../../_/auth.mjs';
import { g as getLedgerResource } from '../../../_/ledger-api.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/auth-store.mjs';

const accounts_get = defineEventHandler((event) => {
  const query = getQuery(event);
  return getLedgerResource(event, "accounts", query, () => filterDemoAccounts(query));
});

export { accounts_get as default };
//# sourceMappingURL=accounts.get.mjs.map
