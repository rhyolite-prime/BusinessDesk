import { d as defineEventHandler } from '../../../../../nitro/nitro.mjs';
import { h as handleVoucherTransition } from '../../../../../_/ledger-voucher-actions.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../../_/ledger-voucher-demo.mjs';
import '../../../../../_/auth.mjs';
import '../../../../../_/auth-store.mjs';

const approve_post = defineEventHandler((event) => handleVoucherTransition(event, "approve"));

export { approve_post as default };
//# sourceMappingURL=approve.post.mjs.map
