import { d as defineEventHandler, g as getQuery, c as createError, u as useRuntimeConfig, a as getHeader } from '../../../../nitro/nitro.mjs';
import { r as requireBusinessDeskSession, g as getNextDemoJournalBatchNumber } from '../../../../_/auth.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/auth-store.mjs';

function isRealDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = /* @__PURE__ */ new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
const nextNumber_get = defineEventHandler(async (event) => {
  var _a;
  const session = await requireBusinessDeskSession(event);
  const batchDate = String((_a = getQuery(event).batchDate) != null ? _a : "").trim();
  if (!isRealDate(batchDate)) {
    throw createError({ statusCode: 400, statusMessage: "Batch date must be a real calendar date in YYYY-MM-DD format." });
  }
  const config = useRuntimeConfig(event);
  const baseUrl = String(config.ledgerApiBaseUrl || "").replace(/\/$/, "");
  if (baseUrl) {
    if (session.demo || !session.accessToken) {
      throw createError({ statusCode: 403, statusMessage: "Demo sign-in cannot access a configured ledger service." });
    }
    return await $fetch(`${baseUrl}/api/v1/ledger/journals/next-number`, {
      query: { batchDate },
      headers: {
        authorization: `Bearer ${session.accessToken}`,
        "x-request-id": getHeader(event, "x-request-id") || crypto.randomUUID()
      }
    });
  }
  if (!config.public.demoMode) {
    throw createError({ statusCode: 503, statusMessage: "Ledger API is not configured", data: { code: "LEDGER_API_UNAVAILABLE" } });
  }
  return { batchNumber: getNextDemoJournalBatchNumber(batchDate) };
});

export { nextNumber_get as default };
//# sourceMappingURL=next-number.get.mjs.map
