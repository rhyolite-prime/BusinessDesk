import { d as defineEventHandler, r as readBody, c as createError, u as useRuntimeConfig, a as getHeader, s as setResponseStatus } from '../../../nitro/nitro.mjs';
import { r as requireBusinessDeskSession, d as demoAccounts } from '../../../_/auth.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/auth-store.mjs';

const accounts_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g;
  const session = await requireBusinessDeskSession(event);
  const body = await readBody(event);
  const accountNumber = String((_a = body == null ? void 0 : body.accountNumber) != null ? _a : "").trim();
  const name = String((_b = body == null ? void 0 : body.name) != null ? _b : "").trim();
  const group = String((_c = body == null ? void 0 : body.group) != null ? _c : "").trim();
  const accountType = String((_d = body == null ? void 0 : body.accountType) != null ? _d : "").trim();
  const currency = String((_e = body == null ? void 0 : body.currency) != null ? _e : "GHS").trim().toUpperCase();
  const accountHeaderId = String((_f = body == null ? void 0 : body.accountHeaderId) != null ? _f : "").trim();
  const status = String((_g = body == null ? void 0 : body.status) != null ? _g : "Active").trim();
  const allowedTypes = /* @__PURE__ */ new Set(["Asset", "Liability", "Equity", "Revenue", "Expense"]);
  const allowedStatuses = /* @__PURE__ */ new Set(["Active", "Inactive"]);
  if (!accountNumber || accountNumber.length > 80 || !name || name.length > 200 || !group || group.length > 160 || !allowedTypes.has(accountType) || !/^[A-Z]{3}$/.test(currency) || accountHeaderId.length > 80 || !allowedStatuses.has(status)) {
    throw createError({ statusCode: 400, statusMessage: "Enter a valid account number, name, group, type, and currency." });
  }
  const config = useRuntimeConfig(event);
  const baseUrl = String(config.ledgerApiBaseUrl || "").replace(/\/$/, "");
  if (baseUrl) {
    if (session.demo || !session.accessToken) {
      throw createError({ statusCode: 403, statusMessage: "Demo sign-in cannot access a configured ledger service." });
    }
    return await $fetch(`${baseUrl}/api/v1/ledger/accounts`, {
      method: "POST",
      body: { accountNumber, name, group, accountType, currency, status, ...accountHeaderId ? { accountHeaderId } : {} },
      headers: {
        authorization: `Bearer ${session.accessToken}`,
        "x-request-id": getHeader(event, "x-request-id") || crypto.randomUUID()
      }
    });
  }
  if (!config.public.demoMode) {
    throw createError({ statusCode: 503, statusMessage: "Ledger API is not configured", data: { code: "LEDGER_API_UNAVAILABLE" } });
  }
  if (demoAccounts.some((account2) => account2.accountNumber.toLowerCase() === accountNumber.toLowerCase())) {
    throw createError({ statusCode: 409, statusMessage: "That account number is already in use." });
  }
  const account = {
    id: `demo-${crypto.randomUUID()}`,
    accountNumber,
    name,
    group,
    accountType,
    currency,
    ...accountHeaderId ? { accountHeaderId } : {},
    balance: "0.00",
    status
  };
  demoAccounts.unshift(account);
  setResponseStatus(event, 201);
  return account;
});

export { accounts_post as default };
//# sourceMappingURL=accounts.post.mjs.map
