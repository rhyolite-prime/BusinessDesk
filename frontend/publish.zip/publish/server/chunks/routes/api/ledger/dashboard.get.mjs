import { d as defineEventHandler } from '../../../nitro/nitro.mjs';
import { a as demoDashboard } from '../../../_/auth.mjs';
import { g as getLedgerResource } from '../../../_/ledger-api.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/auth-store.mjs';

const dashboard_get = defineEventHandler(
  (event) => getLedgerResource(event, "dashboard", {}, () => demoDashboard)
);

export { dashboard_get as default };
//# sourceMappingURL=dashboard.get.mjs.map
