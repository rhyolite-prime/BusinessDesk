import { d as defineEventHandler, b as getRouterParam, c as createError, u as useRuntimeConfig, a as getHeader } from '../../../../nitro/nitro.mjs';
import { r as requireBusinessDeskSession, d as demoAccounts } from '../../../../_/auth.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../../_/auth-store.mjs';

const _id__delete = defineEventHandler(async (event) => {
  const session = await requireBusinessDeskSession(event);
  const id = getRouterParam(event, "id");
  if (!id) throw createError({ statusCode: 400, statusMessage: "An account id is required." });
  const config = useRuntimeConfig(event);
  const baseUrl = String(config.ledgerApiBaseUrl || "").replace(/\/$/, "");
  if (baseUrl) {
    if (session.demo || !session.accessToken) {
      throw createError({ statusCode: 403, statusMessage: "Demo sign-in cannot access a configured ledger service." });
    }
    await $fetch(`${baseUrl}/api/v1/ledger/accounts/${encodeURIComponent(id)}`, {
      method: "DELETE",
      headers: {
        authorization: `Bearer ${session.accessToken}`,
        "x-request-id": getHeader(event, "x-request-id") || crypto.randomUUID()
      }
    });
    return { id, deleted: true };
  }
  if (!config.public.demoMode) {
    throw createError({ statusCode: 503, statusMessage: "Ledger API is not configured", data: { code: "LEDGER_API_UNAVAILABLE" } });
  }
  const index = demoAccounts.findIndex((account) => account.id === id);
  if (index < 0) throw createError({ statusCode: 404, statusMessage: "Ledger account not found." });
  demoAccounts.splice(index, 1);
  return { id, deleted: true };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
