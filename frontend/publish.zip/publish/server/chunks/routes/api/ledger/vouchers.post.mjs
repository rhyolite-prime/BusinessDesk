import { d as defineEventHandler, r as readBody, u as useRuntimeConfig, c as createError, a as getHeader, s as setResponseStatus } from '../../../nitro/nitro.mjs';
import { n as nextDemoVoucherNumbers, s as saveDemoVoucher } from '../../../_/ledger-voucher-demo.mjs';
import { r as requireBusinessDeskSession } from '../../../_/auth.mjs';
import { n as normalizeVoucherInput } from '../../../_/ledger-voucher-validation.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/auth-store.mjs';
import '../../../_/setup-data.mjs';
import '../../../_/organization-data.mjs';

const vouchers_post = defineEventHandler(async (event) => {
  const session = await requireBusinessDeskSession(event);
  const body = await readBody(event);
  const config = useRuntimeConfig(event);
  const baseUrl = String(config.ledgerApiBaseUrl || "").replace(/\/$/, "");
  if (baseUrl) {
    if (session.demo || !session.accessToken) {
      throw createError({ statusCode: 403, statusMessage: "Demo sign-in cannot access a configured ledger service." });
    }
    return await $fetch(`${baseUrl}/api/v1/ledger/vouchers`, {
      method: "POST",
      body,
      headers: {
        authorization: `Bearer ${session.accessToken}`,
        "x-request-id": getHeader(event, "x-request-id") || crypto.randomUUID()
      }
    });
  }
  if (!config.public.demoMode) {
    throw createError({ statusCode: 503, statusMessage: "Ledger API is not configured", data: { code: "LEDGER_API_UNAVAILABLE" } });
  }
  const normalized = normalizeVoucherInput(body);
  const { voucherNumber, batchNumber } = nextDemoVoucherNumbers(normalized.type, normalized.entryDate.slice(0, 4));
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const voucher = {
    ...normalized,
    id: `demo-${crypto.randomUUID()}`,
    voucherNumber,
    batchNumber,
    status: "Draft",
    preparer: session.username,
    createdAt: now,
    updatedAt: now
  };
  saveDemoVoucher(voucher);
  setResponseStatus(event, 201);
  return voucher;
});

export { vouchers_post as default };
//# sourceMappingURL=vouchers.post.mjs.map
