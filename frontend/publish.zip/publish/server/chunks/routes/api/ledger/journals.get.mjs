import { d as defineEventHandler, g as getQuery } from '../../../nitro/nitro.mjs';
import { b as filterDemoJournals } from '../../../_/auth.mjs';
import { g as getLedgerResource } from '../../../_/ledger-api.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '../../../_/auth-store.mjs';

const journals_get = defineEventHandler((event) => {
  const query = getQuery(event);
  return getLedgerResource(event, "journals", query, () => filterDemoJournals(query));
});

export { journals_get as default };
//# sourceMappingURL=journals.get.mjs.map
