import { d as defineEventHandler } from '../../nitro/nitro.mjs';
import { d as db } from '../../_/db.mjs';
import 'unhead/server';
import 'vue';
import 'unhead/legacy';
import 'unhead/plugins';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const health_get = defineEventHandler((event) => {
  const d = db();
  return {
    status: "UP",
    service: "tl-core-banking-api (mock)",
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    counts: {
      clients: d.clients.length,
      loans: d.loans.length,
      savings: d.savings.length,
      journalEntries: d.journals.length,
      pendingTasks: d.tasks.filter((t) => t.status === "pending").length
    }
  };
});

export { health_get as default };
//# sourceMappingURL=health.get.mjs.map
