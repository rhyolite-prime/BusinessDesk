import nodeCrypto from 'node:crypto';

const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function base32Encode(buf) {
  let bits = 0;
  let value = 0;
  let out = "";
  for (const byte of buf) {
    value = value << 8 | byte;
    bits += 8;
    while (bits >= 5) {
      out += B32[value >>> bits - 5 & 31];
      bits -= 5;
    }
    value &= (1 << bits) - 1;
  }
  if (bits > 0) out += B32[value << 5 - bits & 31];
  return out;
}
function base32Decode(secret) {
  const clean = secret.replace(/=+$/g, "").toUpperCase().replace(/[^A-Z2-7]/g, "");
  let bits = 0;
  let value = 0;
  const bytes = [];
  for (const ch of clean) {
    value = value << 5 | B32.indexOf(ch);
    bits += 5;
    if (bits >= 8) {
      bytes.push(value >>> bits - 8 & 255);
      bits -= 8;
      value &= (1 << bits) - 1;
    }
  }
  return Buffer.from(bytes);
}
function generateTotpSecret() {
  return base32Encode(nodeCrypto.randomBytes(20));
}
function totpFromTime(secret, time, step = 30, digits = 6) {
  const key = base32Decode(secret);
  const counter = Math.floor(time / step);
  const buf = Buffer.alloc(8);
  buf.writeBigUInt64BE(BigInt(counter));
  const hmac = nodeCrypto.createHmac("sha1", key).update(buf).digest();
  const offset = hmac[hmac.length - 1] & 15;
  const code = (hmac[offset] & 127) << 24 | (hmac[offset + 1] & 255) << 16 | (hmac[offset + 2] & 255) << 8 | hmac[offset + 3] & 255;
  return String(code % 10 ** digits).padStart(digits, "0");
}
function verifyTotp(secret, token, step = 30) {
  const clean = String(token).replace(/\s+/g, "");
  if (!/^\d{6}$/.test(clean)) return false;
  const now = Math.floor(Date.now() / 1e3);
  for (const drift of [-1, 0, 1]) {
    if (totpFromTime(secret, now + drift * step, step) === clean) return true;
  }
  return false;
}
function currentTotp(secret) {
  return totpFromTime(secret, Math.floor(Date.now() / 1e3));
}
function otpauthUrl(secret, issuer, account) {
  const label = encodeURIComponent(`${issuer}:${account}`);
  const params = new URLSearchParams({
    secret,
    issuer,
    algorithm: "SHA1",
    digits: "6",
    period: "30"
  });
  return `otpauth://totp/${label}?${params.toString()}`;
}

export { currentTotp as c, generateTotpSecret as g, otpauthUrl as o, verifyTotp as v };
//# sourceMappingURL=totp.mjs.map
