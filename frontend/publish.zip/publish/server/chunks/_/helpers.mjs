import { c as createError } from '../nitro/nitro.mjs';

function badRequest(msg) {
  return createError({ statusCode: 400, statusMessage: msg, message: msg });
}

export { badRequest as b };
//# sourceMappingURL=helpers.mjs.map
