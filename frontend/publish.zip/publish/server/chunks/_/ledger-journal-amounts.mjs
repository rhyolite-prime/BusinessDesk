import { l as ledgerCurrencyOptions, p as parseLedgerRate, L as LEDGER_RATE_SCALE, a as parseLedgerAmount, c as convertLedgerAmount, f as formatLedgerAmount } from './setup-data.mjs';

const baseCurrencyCode = "GHS";
function formatRate(rateUnits) {
  const whole = rateUnits / LEDGER_RATE_SCALE;
  const fraction = String(rateUnits % LEDGER_RATE_SCALE).padStart(10, "0");
  return `${whole}.${fraction}`;
}
function normalizeJournalLineAmounts(input, lineNumber, isMultiCurrency) {
  var _a, _b, _c, _d, _e, _f, _g;
  const errors = [];
  const currencyCode = String((_a = input.currencyCode) != null ? _a : baseCurrencyCode).trim().toUpperCase();
  const currency = ledgerCurrencyOptions.find((option) => option.code === currencyCode);
  if (!currency) errors.push(`Line ${lineNumber}: select a supported transaction currency.`);
  if (!isMultiCurrency && currencyCode !== baseCurrencyCode) {
    errors.push(`Line ${lineNumber}: enable multi-currency to use a currency other than ${baseCurrencyCode}.`);
  }
  const providedRate = String((_b = input.exchangeRate) != null ? _b : "").trim();
  const rateText = providedRate || (currencyCode === baseCurrencyCode ? "1" : "");
  const rateUnits = parseLedgerRate(rateText);
  if (rateUnits === null || rateUnits <= BigInt(0)) {
    errors.push(`Line ${lineNumber}: exchange rate must be positive and have at most 10 decimal places.`);
  } else if (currencyCode === baseCurrencyCode && rateUnits !== LEDGER_RATE_SCALE) {
    errors.push(`Line ${lineNumber}: ${baseCurrencyCode} lines must use an exchange rate of 1.`);
  }
  const debitInput = isMultiCurrency ? String((_c = input.foreignDebit) != null ? _c : currencyCode === baseCurrencyCode ? input.debit : "") : String((_d = input.debit) != null ? _d : "");
  const creditInput = isMultiCurrency ? String((_e = input.foreignCredit) != null ? _e : currencyCode === baseCurrencyCode ? input.credit : "") : String((_f = input.credit) != null ? _f : "");
  const transactionDebitUnits = parseLedgerAmount(debitInput, true);
  const transactionCreditUnits = parseLedgerAmount(creditInput, true);
  if (transactionDebitUnits === null) errors.push(`Line ${lineNumber}: debit must be a non-negative decimal with at most 14 whole digits and 6 decimal places.`);
  if (transactionCreditUnits === null) errors.push(`Line ${lineNumber}: credit must be a non-negative decimal with at most 14 whole digits and 6 decimal places.`);
  if (transactionDebitUnits !== null && transactionCreditUnits !== null) {
    if (transactionDebitUnits > BigInt(0) && transactionCreditUnits > BigInt(0)) {
      errors.push(`Line ${lineNumber}: enter an amount on either debit or credit, not both.`);
    }
    if (transactionDebitUnits === BigInt(0) && transactionCreditUnits === BigInt(0)) {
      errors.push(`Line ${lineNumber}: either debit or credit must be greater than zero.`);
    }
  }
  const safeRateUnits = rateUnits && rateUnits > BigInt(0) ? rateUnits : LEDGER_RATE_SCALE;
  const safeDebitUnits = transactionDebitUnits != null ? transactionDebitUnits : BigInt(0);
  const safeCreditUnits = transactionCreditUnits != null ? transactionCreditUnits : BigInt(0);
  const baseDebitUnits = isMultiCurrency ? convertLedgerAmount(safeDebitUnits, safeRateUnits) : safeDebitUnits;
  const baseCreditUnits = isMultiCurrency ? convertLedgerAmount(safeCreditUnits, safeRateUnits) : safeCreditUnits;
  if (safeDebitUnits > BigInt(0) && baseDebitUnits === BigInt(0) || safeCreditUnits > BigInt(0) && baseCreditUnits === BigInt(0)) {
    errors.push(`Line ${lineNumber}: converted ${baseCurrencyCode} amount must be greater than zero.`);
  }
  if (parseLedgerAmount(formatLedgerAmount(baseDebitUnits)) === null || parseLedgerAmount(formatLedgerAmount(baseCreditUnits)) === null) {
    errors.push(`Line ${lineNumber}: converted ${baseCurrencyCode} amount exceeds the supported range.`);
  }
  if (errors.length) return { errors };
  const debitUnits = baseDebitUnits;
  const creditUnits = baseCreditUnits;
  const foreignDebitUnits = isMultiCurrency ? safeDebitUnits : debitUnits;
  const foreignCreditUnits = isMultiCurrency ? safeCreditUnits : creditUnits;
  return {
    errors,
    value: {
      currencyCode,
      currencyName: (_g = currency == null ? void 0 : currency.name) != null ? _g : currencyCode,
      exchangeRate: formatRate(safeRateUnits),
      foreignDebit: formatLedgerAmount(foreignDebitUnits),
      foreignCredit: formatLedgerAmount(foreignCreditUnits),
      debit: formatLedgerAmount(debitUnits),
      credit: formatLedgerAmount(creditUnits),
      debitUnits,
      creditUnits
    }
  };
}

export { normalizeJournalLineAmounts as n };
//# sourceMappingURL=ledger-journal-amounts.mjs.map
