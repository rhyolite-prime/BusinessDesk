function store() {
  if (!globalThis.__tlAuth) {
    globalThis.__tlAuth = {
      sessions: /* @__PURE__ */ new Map(),
      pendingLogin: /* @__PURE__ */ new Map(),
      totp: /* @__PURE__ */ new Map(),
      passwords: /* @__PURE__ */ new Map()
    };
  }
  return globalThis.__tlAuth;
}
const authStore = store;

export { authStore as a };
//# sourceMappingURL=auth-store.mjs.map
