import { e as getCookie, c as createError } from '../nitro/nitro.mjs';
import { a as authStore } from './auth-store.mjs';

const demoAccounts = [
  { id: "acc-1000", accountNumber: "1000", name: "Cash on Hand", group: "Current Assets", accountType: "Asset", currency: "GHS", accountHeaderId: "control-petty-cash", balance: "12450.00", status: "Active" },
  { id: "acc-12307", accountNumber: "12307", name: "Petty Cash \u2014 CBS", group: "Current Assets", accountType: "Asset", currency: "GHS", accountHeaderId: "control-petty-cash", balance: "1482.00", status: "Active" },
  { id: "acc-1010", accountNumber: "1010", name: "Bank \u2014 Main Operating", group: "Current Assets", accountType: "Asset", currency: "GHS", accountHeaderId: "control-bank-accounts", balance: "548219.75", status: "Active" },
  { id: "acc-1020", accountNumber: "1020", name: "Bank \u2014 USD Account", group: "Current Assets", accountType: "Asset", currency: "USD", accountHeaderId: "control-bank-accounts", balance: "18750.00", status: "Active" },
  { id: "acc-1100", accountNumber: "1100", name: "Trade Receivables", group: "Current Assets", accountType: "Asset", currency: "GHS", accountHeaderId: "control-receivables", balance: "193420.83", status: "Active" },
  { id: "acc-1500", accountNumber: "1500", name: "Office Equipment", group: "Non-current Assets", accountType: "Asset", currency: "GHS", accountHeaderId: "control-ppe", balance: "88400.00", status: "Active" },
  { id: "acc-2000", accountNumber: "2000", name: "Trade Payables", group: "Current Liabilities", accountType: "Liability", currency: "GHS", accountHeaderId: "control-payables", balance: "98210.40", status: "Active" },
  { id: "acc-2200", accountNumber: "2200", name: "Withholding Tax Payable", group: "Current Liabilities", accountType: "Liability", currency: "GHS", accountHeaderId: "control-tax-payables", balance: "18450.00", status: "Active" },
  { id: "acc-3000", accountNumber: "3000", name: "Stated Capital", group: "Equity", accountType: "Equity", currency: "GHS", accountHeaderId: "control-share-capital", balance: "400000.00", status: "Active" },
  { id: "acc-4000", accountNumber: "4000", name: "Service Revenue", group: "Revenue", accountType: "Revenue", currency: "GHS", accountHeaderId: "control-operating-revenue", balance: "389250.00", status: "Active" },
  { id: "acc-5000", accountNumber: "5000", name: "Operating Expenses", group: "Expenses", accountType: "Expense", currency: "GHS", accountHeaderId: "control-operating-expenses", balance: "124180.43", status: "Active" },
  { id: "acc-50016", accountNumber: "50016", name: "Transport & Travels", group: "Expenses", accountType: "Expense", currency: "GHS", accountHeaderId: "control-operating-expenses", balance: "0.00", status: "Active" },
  { id: "acc-50018", accountNumber: "50018", name: "Food & Entertainment", group: "Expenses", accountType: "Expense", currency: "GHS", accountHeaderId: "control-operating-expenses", balance: "0.00", status: "Active" },
  { id: "acc-50023", accountNumber: "50023", name: "PC Hardware Software", group: "Expenses", accountType: "Expense", currency: "GHS", accountHeaderId: "control-operating-expenses", balance: "0.00", status: "Active" },
  { id: "acc-50029", accountNumber: "50029", name: "Postal Expenses", group: "Expenses", accountType: "Expense", currency: "GHS", accountHeaderId: "control-operating-expenses", balance: "0.00", status: "Active" },
  { id: "acc-50050", accountNumber: "50050", name: "Telephone & Communications", group: "Expenses", accountType: "Expense", currency: "GHS", accountHeaderId: "control-operating-expenses", balance: "0.00", status: "Active" },
  { id: "acc-5100", accountNumber: "5100", name: "Foreign Exchange Loss", group: "Expenses", accountType: "Expense", currency: "GHS", accountHeaderId: "control-fx-loss", balance: "1820.14", status: "Inactive" }
];
const demoJournals = [
  { id: "jrn-001", batchNumber: "GJ-2026-0042", description: "Monthly depreciation \u2014 April", date: "2026-04-30", source: "General journal", debit: "12500.00", credit: "12500.00", status: "Posted", preparer: "E. Mensah" },
  { id: "jrn-002", batchNumber: "GJ-2026-0041", description: "Accrual \u2014 utilities", date: "2026-04-29", source: "General journal", debit: "4830.00", credit: "4830.00", status: "Pending approval", preparer: "K. Agyeman" },
  { id: "jrn-003", batchNumber: "PV-2026-0118", description: "Office supplies \u2014 Adom Trading", date: "2026-04-28", source: "Payment voucher", debit: "2640.00", credit: "2640.00", status: "Approved", preparer: "M. Boateng" },
  { id: "jrn-004", batchNumber: "RC-2026-0076", description: "Consulting receipt \u2014 Akua Co.", date: "2026-04-27", source: "Cash receipt", debit: "18750.00", credit: "18750.00", status: "Posted", preparer: "E. Mensah" },
  {
    id: "jrn-005",
    batchNumber: "GJ-2026-0040",
    description: "FX revaluation \u2014 USD balances",
    date: "2026-04-26",
    source: "Revaluation",
    debit: "1820.140000",
    credit: "1820.140000",
    status: "Draft",
    preparer: "K. Agyeman",
    isMultiCurrency: true,
    lineCount: 2,
    lines: [
      { id: "jrn-005-line-1", accountId: "acc-5100", accountNumber: "5100", accountName: "Foreign Exchange Loss", referenceNumber: "FX-APR-2026", description: "Unrealized exchange loss", currencyCode: "GHS", currencyName: "Ghana cedi", exchangeRate: "1.0000000000", foreignDebit: "1820.140000", foreignCredit: "0.000000", debit: "1820.140000", credit: "0.000000" },
      { id: "jrn-005-line-2", accountId: "acc-1020", accountNumber: "1020", accountName: "Bank \u2014 USD Account", referenceNumber: "FX-APR-2026", description: "Revaluation of USD bank balance", currencyCode: "USD", currencyName: "US dollar", exchangeRate: "12.5000000000", foreignDebit: "0.000000", foreignCredit: "145.611200", debit: "0.000000", credit: "1820.140000" }
    ]
  },
  { id: "jrn-006", batchNumber: "GJ-2026-0039", description: "Correction \u2014 duplicate accrual", date: "2026-04-24", source: "Reversal", debit: "930.00", credit: "930.00", status: "Reversed", preparer: "M. Boateng" }
];
function getNextDemoJournalBatchNumber(batchDate) {
  const year = batchDate.slice(0, 4);
  const pattern = new RegExp(`^GJ-${year}-(\\d+)$`);
  const highestSequence = demoJournals.reduce((highest, journal) => {
    const match = journal.batchNumber.match(pattern);
    return match ? Math.max(highest, Number(match[1])) : highest;
  }, 0);
  return `GJ-${year}-${String(highestSequence + 1).padStart(4, "0")}`;
}
const demoDashboard = {
  accountingUnit: { id: "unit-accra", name: "Accra Operations", code: "ACC-01", baseCurrency: "GHS" },
  asOf: "2026-04-30",
  metrics: [
    { key: "assets", label: "Total assets", amount: "1248420.58", currency: "GHS", changeLabel: "+8.2% vs last month", direction: "up", note: "Posted balances" },
    { key: "liabilities", label: "Total liabilities", amount: "482310.12", currency: "GHS", changeLabel: "\u22122.4% vs last month", direction: "down", note: "Posted balances" },
    { key: "revenue", label: "Revenue", amount: "389250.00", currency: "GHS", changeLabel: "+12.6% vs last month", direction: "up", note: "Year to date" },
    { key: "expenditure", label: "Expenditure", amount: "124180.43", currency: "GHS", changeLabel: "+3.1% vs last month", direction: "neutral", note: "Year to date" }
  ],
  cashPosition: [
    { label: "Cash on hand", amount: "12450.00", currency: "GHS", change: "+2.1%" },
    { label: "Main operating bank", amount: "548219.75", currency: "GHS", change: "+5.8%" },
    { label: "USD bank account", amount: "18750.00", currency: "USD", change: "As at 30 Apr" }
  ],
  recentJournals: demoJournals.slice(0, 5)
};
function filterDemoAccounts(query) {
  var _a, _b;
  const search = String((_a = query.search) != null ? _a : "").trim().toLowerCase();
  const status = String((_b = query.status) != null ? _b : "").trim().toLowerCase();
  const items = demoAccounts.filter((account) => {
    const matchesSearch = !search || [account.accountNumber, account.name, account.group, account.accountType].some((value) => value.toLowerCase().includes(search));
    const matchesStatus = !status || account.status.toLowerCase() === status;
    return matchesSearch && matchesStatus;
  });
  return { items, total: items.length };
}
function filterDemoJournals(query) {
  var _a, _b;
  const search = String((_a = query.search) != null ? _a : "").trim().toLowerCase();
  const status = String((_b = query.status) != null ? _b : "").trim().toLowerCase();
  const items = demoJournals.filter((journal) => {
    const matchesSearch = !search || [journal.batchNumber, journal.description, journal.source, journal.preparer].some((value) => value.toLowerCase().includes(search));
    const matchesStatus = !status || journal.status.toLowerCase().includes(status);
    return matchesSearch && matchesStatus;
  });
  return { items, total: items.length };
}

async function requireBusinessDeskSession(event) {
  const token = getCookie(event, "tl_session");
  const session = token ? authStore().sessions.get(token) : void 0;
  if (!session) {
    throw createError({ statusCode: 401, statusMessage: "Sign in is required to access the ledger." });
  }
  return {
    userId: session.userId,
    username: session.username,
    demo: true,
    accessToken: null
  };
}

export { demoDashboard as a, filterDemoJournals as b, demoJournals as c, demoAccounts as d, filterDemoAccounts as f, getNextDemoJournalBatchNumber as g, requireBusinessDeskSession as r };
//# sourceMappingURL=auth.mjs.map
