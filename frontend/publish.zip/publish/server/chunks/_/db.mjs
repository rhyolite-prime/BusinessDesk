function mulberry32(seed) {
  return function() {
    let t = seed += 1831565813;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(20260903);
const r = (min, max) => min + rnd() * (max - min);
const ri = (min, max) => Math.floor(r(min, max + 1));
const pick = (arr) => arr[Math.floor(rnd() * arr.length)];
const round2 = (n) => Math.round(n * 100) / 100;
const DAY = 864e5;
const todayISO = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
const dISO = (d) => d.toISOString().slice(0, 10);
const daysAgo = (n) => dISO(new Date(Date.now() - n * DAY));
const daysAhead = (n) => dISO(new Date(Date.now() + n * DAY));
function addPeriod(dateISO, n, unit) {
  const d = /* @__PURE__ */ new Date(dateISO + "T12:00:00Z");
  if (unit === "weeks") d.setUTCDate(d.getUTCDate() + n * 7);
  else d.setUTCMonth(d.getUTCMonth() + n);
  return dISO(d);
}
const MALE = ["Kofi", "Kwame", "Kojo", "Kwesi", "Yaw", "Fiifi", "Ekow", "Kobina", "Akwasi", "Kwabena", "Mensah", "Selorm", "Edem", "Elorm", "Tweneboah", "Nana", "Osei", "Kojo", "Ato", "Kweku"];
const FEMALE = ["Ama", "Abena", "Yaa", "Adjoa", "Esi", "Akua", "Afia", "Efua", "Akorfa", "Dzifa", "Afi", "Serwaa", "Akosua", "Adwoa", "Abina", "Ekua", "Ama", "Dede", "Ayeley", "Lami"];
const SURNAMES = ["Mensah", "Owusu", "Asante", "Boateng", "Osei", "Acheampong", "Appiah", "Nyamekye", "Adjei", "Darko", "Agyeman", "Frimpong", "Aidoo", "Quaye", "Tetteh", "Annan", "Sarpong", "Agyei", "Bonsu", "Ankrah", "Amponsah", "Donkor", "Gyasi", "Kwarteng", "Nti", "Amoah", "Yeboah", "Opoku", "Awuah", "Baidoo"];
const TOWNS = ["Osu", "Makola", "Madina", "Tema Newtown", "Nima", "Kaneshie", "Dansoman", "Adum", "Asawase", "Tafo", "Sekondi", "Tarkwa", "Saketumo", "Lamashegu", "Vitting", "Pedu", "Abakam", "Koforidua Zongo", "Ho Dome", "Cape Coast North"];
const CITIES = ["Accra", "Kumasi", "Takoradi", "Tamale", "Tema", "Cape Coast"];
const BUSINESSES = ["Ama Serwaa Provisions", "Kwame Nyame Cold Store", "Adjoa Beauty Spot", "Osei & Sons Trading", "Mama Akua Kenkey Base", "Kumasi Spare Parts Depot", "Esi Fashion House", "Boateng Hardware", "Suhum Mobile Money Point", "Makola Textiles", "Fiifi Phone Shop", "Sister Efua Catering", "Anloga Agro Inputs", "Tema Auto Repairs", "Yaa Beddings & More", "Nana K. Woodworks", "Tamale Shea Cooperative", "Dansoman Bakery", "Teshie Fish Mongers", "Aboaso Poultry Farm"];
const PURPOSES = ["Working capital / trading stock", "Market wares expansion", "Agriculture inputs (fertiliser, seeds)", "Equipment purchase", "School fees", "Rent advance", "Vehicle repairs & maintenance", "Processing machine", "Inventory top-up for festive season", "Livestock restocking"];
const COLLATERAL = ["Two guarantors (group cross-guarantee)", "Radio / television set", "Sewing machine", "Refrigerator", "Motorcycle (Nimde\u025B)", "Generator set", "Kiosk structure", "Stock of goods (floating lien)", "Salary domiciliation", "None \u2014 character-based lending"];
const MEETING_DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"];
const GROUP_NAMES = ["Ahobraseye Savings Group", "Nn\u0254no\u0254ma Women\u2019s Collective", "Boahemaa Traders Union", "Akwaaba Susu Circle", "Sika Mprospect Group", "\u0190nne Y\u025B Group", "Adom Nwapa Collective", "Nkosuo Market Group", "Ayenkwa Youth Savers", "Dwumadie Business Circle", "Obaatanpa Women\u2019s Group", "Tumi Kura Cooperative", "Aseda Susu Group", "Ntoaso Farmers Circle", "\u0190hira Y\u025B Group", "Mmaa Nkomo Collective", "Ahwenepa Trading Group", "Kukrudu Development Union"];
const POSITIONS = ["Branch Manager", "Loan Officer", "Senior Loan Officer", "Teller / Cashier", "Customer Service Officer", "Accountant", "Internal Auditor", "Relationship Officer"];
const OFFICES_SEED = [
  { name: "Head Office \u2014 Accra", parentId: null, openingDate: "2018-01-15", externalId: "OFF-HQ-001", status: "active" },
  { name: "Kumasi Branch", parentId: 1, openingDate: "2019-03-01", externalId: "OFF-KMS-002", status: "active" },
  { name: "Takoradi Branch", parentId: 1, openingDate: "2020-06-12", externalId: "OFF-TKD-003", status: "active" },
  { name: "Tamale Branch", parentId: 1, openingDate: "2021-02-20", externalId: "OFF-TML-004", status: "active" },
  { name: "Tema Community 1 Branch", parentId: 1, openingDate: "2022-09-05", externalId: "OFF-TMA-005", status: "active" },
  { name: "Cape Coast Branch", parentId: 1, openingDate: "2023-05-18", externalId: "OFF-CC-006", status: "active" }
];
const LOAN_PRODUCTS = [
  { name: "Market Trader Loan", shortName: "MTL", description: "Short-term working capital for market traders. Repaid weekly from sales.", principalMin: 200, principalMax: 5e3, interestRateMin: 5, interestRateMax: 8, termMin: 8, termMax: 24, termFrequency: "weeks", repayEvery: 1, repayFrequency: "weeks", graceOnPrincipal: 0, active: true },
  { name: "Susu Booster Loan", shortName: "SBL", description: "Top-up for consistent susu savers; limit grows with savings history.", principalMin: 300, principalMax: 8e3, interestRateMin: 4, interestRateMax: 7, termMin: 16, termMax: 48, termFrequency: "weeks", repayEvery: 2, repayFrequency: "weeks", graceOnPrincipal: 1, active: true },
  { name: "Micro Business Loan", shortName: "MBL", description: "Term loan for established micro and small businesses.", principalMin: 2e3, principalMax: 5e4, interestRateMin: 18, interestRateMax: 30, termMin: 4, termMax: 18, termFrequency: "months", repayEvery: 1, repayFrequency: "months", graceOnPrincipal: 1, active: true },
  { name: "Salary Advance", shortName: "SAL", description: "Deducted-at-source advance for salaried workers.", principalMin: 1e3, principalMax: 3e4, interestRateMin: 12, interestRateMax: 20, termMin: 3, termMax: 12, termFrequency: "months", repayEvery: 1, repayFrequency: "months", graceOnPrincipal: 0, active: true },
  { name: "Agri Value-Chain Loan", shortName: "AGV", description: "Seasonal finance for crop and livestock farmers; bullet-friendly grace period.", principalMin: 1500, principalMax: 4e4, interestRateMin: 15, interestRateMax: 24, termMin: 6, termMax: 18, termFrequency: "months", repayEvery: 1, repayFrequency: "months", graceOnPrincipal: 3, active: true },
  { name: "Group Enterprise Loan", shortName: "GEL", description: "Joint-liability lending through recognised solidarity groups.", principalMin: 500, principalMax: 15e3, interestRateMin: 5, interestRateMax: 9, termMin: 20, termMax: 52, termFrequency: "weeks", repayEvery: 1, repayFrequency: "weeks", graceOnPrincipal: 0, active: true }
];
const SAVINGS_PRODUCTS = [
  { name: "Susu Savings", shortName: "SUSU", description: "No-frills daily/weekly savings for individuals and groups.", type: "savings", interestRate: 3, minOpeningBalance: 20, withdrawalFee: 0, lockinDays: 0, active: true },
  { name: "Current Account", shortName: "CUR", description: "Transactional account for businesses; cheque book available.", type: "current", interestRate: 0, minOpeningBalance: 100, withdrawalFee: 2, lockinDays: 0, active: true },
  { name: "Fixed Deposit", shortName: "FD", description: "Lump-sum investment at premium rates, 90\u2013365 day tenors.", type: "fixed", interestRate: 12, minOpeningBalance: 500, withdrawalFee: 0, lockinDays: 90, active: true },
  { name: "Recurring Deposit", shortName: "RD", description: "Disciplined monthly savings toward a target amount.", type: "recurring", interestRate: 7, minOpeningBalance: 50, withdrawalFee: 5, lockinDays: 30, active: true },
  { name: "Youth Savers", shortName: "YTH", description: "Custodial account for under-18s; free deposits.", type: "savings", interestRate: 4, minOpeningBalance: 10, withdrawalFee: 0, lockinDays: 0, active: true }
];
const CHARGES = [
  { name: "Loan processing fee", chargeType: "fee", appliesTo: "loan", amountMode: "percent", amount: 2, due: "disbursement", active: true },
  { name: "Late repayment penalty", chargeType: "penalty", appliesTo: "loan", amountMode: "percent", amount: 1.5, due: "installment", active: true },
  { name: "Loan application fee", chargeType: "fee", appliesTo: "loan", amountMode: "flat", amount: 25, due: "specified", active: true },
  { name: "Savings withdrawal charge", chargeType: "fee", appliesTo: "savings", amountMode: "flat", amount: 2, due: "withdrawal", active: true },
  { name: "Monthly ledger fee", chargeType: "fee", appliesTo: "savings", amountMode: "flat", amount: 5, due: "monthly", active: true },
  { name: "Account opening fee", chargeType: "fee", appliesTo: "savings", amountMode: "flat", amount: 10, due: "specified", active: true },
  { name: "Dormant account reactivation", chargeType: "fee", appliesTo: "savings", amountMode: "flat", amount: 15, due: "specified", active: true },
  { name: "Card / cheque book request", chargeType: "fee", appliesTo: "client", amountMode: "flat", amount: 30, due: "specified", active: true }
];
const PAYMENT_TYPES = [
  { name: "Cash", isCash: true },
  { name: "Mobile Money \u2014 MTN", isCash: false },
  { name: "Mobile Money \u2014 Telecel", isCash: false },
  { name: "Bank Transfer", isCash: false },
  { name: "Cheque", isCash: false }
];
const GL_SEED = [
  { code: "1000", name: "Assets", type: "ASSET", usage: "header", manual: false, desc: "" },
  { code: "1100", name: "Cash & Bank Balances", type: "ASSET", tag: "CASH", usage: "detail", parent: "1000", manual: false, desc: "Physical cash and nostro balances" },
  { code: "1200", name: "Loan Portfolio", type: "ASSET", tag: "LOAN_PORTFOLIO", usage: "detail", parent: "1000", manual: false, desc: "Gross outstanding performing portfolio" },
  { code: "1300", name: "Interest Receivable", type: "ASSET", tag: "INTEREST_RECEIVABLE", usage: "detail", parent: "1000", manual: false, desc: "Accrued interest not yet due" },
  { code: "1400", name: "Fees Receivable", type: "ASSET", tag: "FEES_RECEIVABLE", usage: "detail", parent: "1000", manual: false, desc: "Accrued fees and penalties" },
  { code: "1500", name: "Office Equipment", type: "ASSET", tag: "EQUIPMENT", usage: "detail", parent: "1000", manual: true, desc: "Furniture, computers and equipment" },
  { code: "2000", name: "Liabilities", type: "LIABILITY", usage: "header", manual: false, desc: "" },
  { code: "2100", name: "Savings Deposits (Control)", type: "LIABILITY", tag: "SAVINGS_CONTROL", usage: "detail", parent: "2000", manual: false, desc: "Customer deposit liability" },
  { code: "2200", name: "Interest Payable on Deposits", type: "LIABILITY", tag: "INTEREST_PAYABLE", usage: "detail", parent: "2000", manual: false, desc: "Accrued deposit interest" },
  { code: "2300", name: "Borrowed Funds", type: "LIABILITY", tag: "BORROWED_FUNDS", usage: "detail", parent: "2000", manual: true, desc: "Wholesale / refinance lines" },
  { code: "2900", name: "Other Liabilities", type: "LIABILITY", tag: "OTHER_LIABILITY", usage: "detail", parent: "2000", manual: true, desc: "Sundry payables" },
  { code: "3000", name: "Equity", type: "EQUITY", usage: "header", manual: false, desc: "" },
  { code: "3100", name: "Share Capital", type: "EQUITY", tag: "EQUITY_CAPITAL", usage: "detail", parent: "3000", manual: true, desc: "Paid-up capital" },
  { code: "3200", name: "Retained Earnings", type: "EQUITY", tag: "RETAINED_EARNINGS", usage: "detail", parent: "3000", manual: false, desc: "Accumulated surplus" },
  { code: "4000", name: "Income", type: "INCOME", usage: "header", manual: false, desc: "" },
  { code: "4100", name: "Interest Income on Loans", type: "INCOME", tag: "INTEREST_INCOME", usage: "detail", parent: "4000", manual: false, desc: "Interest earned on portfolio" },
  { code: "4200", name: "Fee & Penalty Income", type: "INCOME", tag: "FEE_INCOME", usage: "detail", parent: "4000", manual: false, desc: "Processing fees, penalties, ledger fees" },
  { code: "4300", name: "Other Operating Income", type: "INCOME", tag: "OTHER_INCOME", usage: "detail", parent: "4000", manual: true, desc: "Miscellaneous income" },
  { code: "5000", name: "Expenses", type: "EXPENSE", usage: "header", manual: false, desc: "" },
  { code: "5100", name: "Staff Salaries & Benefits", type: "EXPENSE", tag: "STAFF_COSTS", usage: "detail", parent: "5000", manual: true, desc: "Payroll and allowances" },
  { code: "5200", name: "Rent & Utilities", type: "EXPENSE", tag: "RENT_UTILITIES", usage: "detail", parent: "5000", manual: true, desc: "Office rent, electricity, water" },
  { code: "5300", name: "Loan Loss Provision", type: "EXPENSE", tag: "LOAN_LOSS_EXPENSE", usage: "detail", parent: "5000", manual: false, desc: "Provisioning on impaired portfolio" },
  { code: "5400", name: "Loans Written Off", type: "EXPENSE", tag: "WRITTEN_OFF", usage: "detail", parent: "5000", manual: false, desc: "Charged-off principal" },
  { code: "5500", name: "Deposit Interest Expense", type: "EXPENSE", tag: "DEPOSIT_INTEREST", usage: "detail", parent: "5000", manual: false, desc: "Interest paid to depositors" },
  { code: "5600", name: "General Administration", type: "EXPENSE", tag: "ADMIN", usage: "detail", parent: "5000", manual: true, desc: "Stationery, transport, communications" }
];
let txnSeq = 1;
function nextTxnId() {
  return txnSeq++;
}
function buildSchedule(principal, annualRatePct, periods, freq, startDate, grace) {
  const per = freq === "months" ? annualRatePct / 100 / 12 : annualRatePct / 100 / 52;
  const inst = per === 0 ? principal / periods : principal * per / (1 - Math.pow(1 + per, -periods));
  const entries = [];
  let balance = principal;
  for (let i = 1; i <= periods; i++) {
    const interestDue = round2(balance * per);
    let principalDue;
    if (i === periods) principalDue = round2(balance);
    else principalDue = round2(Math.max(0, grace > 0 && i <= grace ? 0 : inst - interestDue));
    if (principalDue > balance) principalDue = round2(balance);
    balance = round2(balance - principalDue);
    const feesDue = i === 1 ? round2(principal * 0.02) : 0;
    entries.push({
      period: i,
      dueDate: addPeriod(startDate, i, freq === "months" ? "months" : "weeks"),
      principalDue,
      interestDue,
      feesDue,
      totalDue: round2(principalDue + interestDue + feesDue),
      principalPaid: 0,
      interestPaid: 0,
      feesPaid: 0,
      paidDate: null
    });
  }
  return entries;
}
function applyPayment(loan, amount, dateISO, paymentType, note = "") {
  const before = {
    f: round2(loan.schedule.reduce((s, e) => s + e.feesPaid, 0)),
    i: round2(loan.schedule.reduce((s, e) => s + e.interestPaid, 0)),
    p: round2(loan.schedule.reduce((s, e) => s + e.principalPaid, 0))
  };
  let remaining = round2(amount);
  for (const e of loan.schedule) {
    if (remaining <= 1e-3) break;
    const payFees = Math.min(remaining, Math.max(0, e.feesDue - e.feesPaid));
    remaining = round2(remaining - payFees);
    const payInt = Math.min(remaining, Math.max(0, e.interestDue - e.interestPaid));
    remaining = round2(remaining - payInt);
    const payPrin = Math.min(remaining, Math.max(0, e.principalDue - e.principalPaid));
    remaining = round2(remaining - payPrin);
    e.feesPaid = round2(e.feesPaid + payFees);
    e.interestPaid = round2(e.interestPaid + payInt);
    e.principalPaid = round2(e.principalPaid + payPrin);
    const settled = e.principalPaid >= e.principalDue - 0.01 && e.interestPaid >= e.interestDue - 0.01 && e.feesPaid >= e.feesDue - 0.01;
    if (settled && !e.paidDate) e.paidDate = dateISO;
  }
  const afterF = round2(loan.schedule.reduce((s, e) => s + e.feesPaid, 0));
  const afterI = round2(loan.schedule.reduce((s, e) => s + e.interestPaid, 0));
  const afterP = round2(loan.schedule.reduce((s, e) => s + e.principalPaid, 0));
  const dFee = round2(afterF - before.f);
  const dInt = round2(afterI - before.i);
  const dPrin = round2(afterP - before.p);
  const accepted = round2(amount - remaining);
  loan.transactions.push({
    id: nextTxnId(),
    date: dateISO,
    type: "repayment",
    amount: accepted,
    fees: dFee,
    interest: dInt,
    principal: dPrin,
    paymentType,
    note: remaining > 0.01 ? `${note} (overpayment ${remaining.toFixed(2)} not accepted)` : note
  });
  recomputeLoan(loan);
  return { accepted, change: remaining };
}
function recomputeLoan(loan) {
  const t = todayISO();
  const paidP = round2(loan.schedule.reduce((s, e) => s + e.principalPaid, 0));
  const paidI = round2(loan.schedule.reduce((s, e) => s + e.interestPaid, 0));
  const paidF = round2(loan.schedule.reduce((s, e) => s + e.feesPaid, 0));
  loan.paidPrincipal = paidP;
  loan.paidInterest = paidI;
  loan.paidFees = paidF;
  const dueP = loan.schedule.reduce((s, e) => s + e.principalDue, 0);
  const dueI = loan.schedule.reduce((s, e) => s + e.interestDue, 0);
  const dueF = loan.schedule.reduce((s, e) => s + e.feesDue, 0);
  loan.outstanding = round2(Math.max(0, dueP + dueI + dueF - paidP - paidI - paidF));
  loan.overdueAmount = round2(loan.schedule.reduce((s, e) => {
    if (e.dueDate < t) return s + Math.max(0, e.totalDue - e.principalPaid - e.interestPaid - e.feesPaid);
    return s;
  }, 0));
  if (loan.status === "active" && loan.outstanding <= 0.01) {
    loan.status = "closed";
    loan.closedDate = t;
    loan.overdueAmount = 0;
  }
}
function buildDB() {
  var _a, _b;
  const db2 = {
    seededAt: (/* @__PURE__ */ new Date()).toISOString(),
    offices: [],
    staff: [],
    clients: [],
    groups: [],
    loanProducts: [],
    savingsProducts: [],
    charges: [],
    loans: [],
    savings: [],
    glAccounts: [],
    journals: [],
    closures: [],
    users: [],
    roles: [],
    tasks: [],
    audit: [],
    paymentTypes: [],
    holidays: [],
    counters: {},
    currentUser: { id: 1, username: "a.mensah", name: "Adjoa Mensah", role: "Super User", officeId: 1 }
  };
  db2.offices = OFFICES_SEED.map((o, i) => ({ ...o, id: i + 1 }));
  [...MALE.slice(0, 10), ...FEMALE.slice(0, 10)];
  for (let i = 0; i < 26; i++) {
    const gender = i % 2 === 0 ? "male" : "female";
    const first = gender === "male" ? MALE[i % MALE.length] : FEMALE[i % FEMALE.length];
    const last = SURNAMES[i * 7 % SURNAMES.length];
    db2.staff.push({
      id: i + 1,
      firstname: first,
      lastname: last,
      displayName: `${first} ${last}`,
      officeId: i % 6 + 1,
      isLoanOfficer: i % 3 !== 0 || POSITIONS[i % POSITIONS.length] === "Senior Loan Officer",
      position: POSITIONS[i % POSITIONS.length],
      mobile: "+233 2" + ri(0, 9) + " " + ri(100, 999) + " " + ri(100, 999),
      status: rnd() < 0.92 ? "active" : "inactive"
    });
  }
  db2.staff[0].position = "Managing Director";
  db2.staff[1].position = "Head of Credit";
  const rolePerms = (mod, actions) => actions.flatMap((a) => [`${mod}.read`, `${mod}.${a}`]);
  db2.roles = [
    { id: 1, name: "Super User", description: "Unrestricted access to all modules and maker-checker bypass.", permissions: ["*"] },
    { id: 2, name: "Branch Manager", description: "Branch-level oversight and approvals.", permissions: ["clients.read", "clients.write", "loans.read", "loans.approve", "loans.disburse", "savings.read", "savings.approve", "savings.write", "accounting.read", "reports.read", "tasks.read", "tasks.check", "organization.read"] },
    { id: 3, name: "Loan Officer", description: "Client onboarding and loan origination.", permissions: ["clients.read", "clients.write", "groups.read", "groups.write", "loans.read", "loans.write", "savings.read", "savings.write"] },
    { id: 4, name: "Teller", description: "Cash transactions over the counter.", permissions: ["clients.read", "savings.read", "savings.deposit", "savings.withdraw", "loans.read", "loans.repay"] },
    { id: 5, name: "Accountant", description: "GL, journal entries and period closure.", permissions: [...rolePerms("accounting", ["write", "close"]), "reports.read", "clients.read"] },
    { id: 6, name: "Internal Auditor", description: "Read-only audit and inspection rights.", permissions: ["audit.read", "reports.read", "clients.read", "loans.read", "savings.read", "accounting.read", "tasks.read"] }
  ];
  const userSeed = [
    ["a.mensah", "Adjoa", "Mensah", [1]],
    ["k.owusu", "Kwame", "Owusu", [2]],
    ["e.sarpong", "Esi", "Sarpong", [3]],
    ["f.ankrah", "Fiifi", "Ankrah", [3]],
    ["a.appiah", "Ama", "Appiah", [4]],
    ["y.darko", "Yaw", "Darko", [5]],
    ["s.aidoo", "Serwaa", "Aidoo", [6]],
    ["t.quaye", "Tweneboah", "Quaye", [2, 3]]
  ];
  db2.users = userSeed.map(([username, fn, ln], i) => ({
    id: i + 1,
    username,
    firstname: fn,
    lastname: ln,
    email: `${username}@sikatrust.example`,
    officeId: i % 6 + 1,
    roleNames: userSeed[i][3].map((rid) => db2.roles[rid - 1].name),
    status: i === 7 ? "disabled" : "active",
    lastLogin: daysAgo(ri(0, 40))
  }));
  db2.loanProducts = LOAN_PRODUCTS.map((p, i) => ({ ...p, id: i + 1 }));
  db2.savingsProducts = SAVINGS_PRODUCTS.map((p, i) => ({ ...p, id: i + 1 }));
  db2.charges = CHARGES.map((c, i) => ({ ...c, id: i + 1 }));
  db2.paymentTypes = PAYMENT_TYPES.map((p, i) => ({ ...p, id: i + 1 }));
  const codeToId = /* @__PURE__ */ new Map();
  db2.glAccounts = GL_SEED.map((g, i) => {
    var _a2, _b2;
    const id = i + 1;
    codeToId.set(g.code, id);
    return {
      id,
      glCode: g.code,
      name: g.name,
      type: g.type,
      tag: (_a2 = g.tag) != null ? _a2 : "",
      parentId: g.parent ? (_b2 = codeToId.get(g.parent)) != null ? _b2 : null : null,
      usage: g.usage,
      manualEntriesAllowed: g.manual,
      description: g.desc
    };
  });
  const glByTag = (tag) => db2.glAccounts.find((a) => a.tag === tag);
  const mobile = () => "+233 2" + ri(0, 9) + " " + ri(100, 999) + " " + ri(100, 999);
  const idTypes = ["Ghana Card", "Voter ID", "Driver's Licence", "NHIS Card", "Passport"];
  for (let i = 0; i < 240; i++) {
    const isBusiness = rnd() < 0.22;
    const gender = rnd() < 0.5 ? "female" : "male";
    const first = gender === "female" ? pick(FEMALE) : pick(MALE);
    const last = pick(SURNAMES);
    const officeId = 1 + Math.floor(Math.pow(rnd(), 1.6) * 6);
    const officers = db2.staff.filter((s) => s.isLoanOfficer && s.officeId === officeId && s.status === "active");
    const staffId = officers.length ? pick(officers).id : db2.staff[0].id;
    const roll = rnd();
    const status = roll < 0.74 ? "active" : roll < 0.86 ? "pending" : roll < 0.94 ? "closed" : "transferred";
    const submittedDate = daysAgo(ri(5, 1100));
    const activationDate = status === "pending" ? null : daysAgo(ri(3, Math.max(4, 1095 - 5)));
    const dobYear = ri(1965, 2002);
    const c = {
      id: i + 1,
      accountNo: "CL-" + String(100001 + i),
      firstname: isBusiness ? "" : first,
      lastname: isBusiness ? "" : last,
      displayName: isBusiness ? pick(BUSINESSES) : `${first} ${last}`,
      externalId: "EXT-C" + (9e4 + ri(1e3, 99999)),
      status,
      clientType: isBusiness ? "business" : "individual",
      businessName: isBusiness ? void 0 : void 0,
      submittedDate,
      activationDate: status === "pending" ? null : activationDate,
      closedDate: status === "closed" ? daysAgo(ri(10, 400)) : null,
      officeId,
      staffId: status === "pending" && rnd() < 0.5 ? null : staffId,
      mobile: mobile(),
      email: isBusiness ? `info@${first.toLowerCase()}.example` : `${first.toLowerCase()}.${last.toLowerCase()}@example.com`,
      gender: isBusiness ? "" : gender,
      dob: `${dobYear}-${String(ri(1, 12)).padStart(2, "0")}-${String(ri(1, 28)).padStart(2, "0")}`,
      idType: pick(idTypes),
      idNumber: "GHA-" + String(ri(1e8, 999999999)),
      address: { line1: `House ${ri(1, 400)}, ${pick(["Lom", "Akp", "Salaga", "Ring", "Market"])} Street`, town: pick(TOWNS), city: CITIES[(officeId - 1) % CITIES.length] },
      groupIds: []
    };
    if (isBusiness) {
      c.businessName = c.displayName;
      c.firstname = first;
      c.lastname = last;
    }
    if (rnd() < 0.7) {
      const rels = ["Spouse", "Sibling", "Child", "Parent"];
      c.family = Array.from({ length: ri(1, 2) }, () => ({
        name: `${pick([...MALE, ...FEMALE])} ${last}`,
        relationship: pick(rels),
        mobile: mobile()
      }));
    }
    c.identifiers = [
      { type: "National ID", number: c.idNumber, status: "verified" },
      ...rnd() < 0.4 ? [{ type: "NHIS", number: "NH" + ri(1e6, 9999999), status: "active" }] : []
    ];
    c.documents = rnd() < 0.6 ? [
      { name: "ID Card Scan", type: "PDF", uploadedAt: submittedDate },
      { name: "Passport Photograph", type: "JPG", uploadedAt: submittedDate }
    ] : [{ name: "ID Card Scan", type: "PDF", uploadedAt: submittedDate }];
    db2.clients.push(c);
  }
  for (let i = 0; i < 18; i++) {
    const officeId = i % 6 + 1;
    const officeClients = db2.clients.filter((c) => c.officeId === officeId && c.status === "active");
    const members = officeClients.sort(() => rnd() - 0.5).slice(0, ri(6, 14));
    const officer = (_a = db2.staff.find((s) => {
      var _a2;
      return s.id === ((_a2 = members[0]) == null ? void 0 : _a2.staffId);
    })) != null ? _a : db2.staff[0];
    const g = {
      id: i + 1,
      name: GROUP_NAMES[i],
      accountNo: "GR-" + String(20001 + i),
      officeId,
      staffId: officer.id,
      meetingDay: pick(MEETING_DAYS),
      formationDate: daysAgo(ri(200, 1500)),
      status: rnd() < 0.85 ? "active" : "pending",
      memberIds: members.map((m) => m.id)
    };
    db2.groups.push(g);
    members.forEach((m) => m.groupIds.push(g.id));
  }
  const ledgers = [];
  const postPair = (date, drTag, crTag, amount, note, officeId = 1) => {
    const txId = "TXN-" + String(1e5 + txnSeq++);
    const mk = (glAccountId, entryType) => ({
      id: 0,
      transactionId: txId,
      entryDate: date,
      officeId,
      glAccountId,
      amount: round2(amount),
      entryType,
      note,
      reversed: false,
      user: "system.seed"
    });
    ledgers.push(mk(glByTag(drTag).id, "DEBIT"), mk(glByTag(crTag).id, "CREDIT"));
    return txId;
  };
  const opening = daysAgo(400);
  postPair(opening, "CASH", "EQUITY_CAPITAL", 85e4, "Opening capital & cash injection");
  postPair(opening, "LOAN_PORTFOLIO", "BORROWED_FUNDS", 62e4, "Opening loan portfolio book");
  postPair(opening, "EQUIPMENT", "CASH", 9e4, "Office equipment capitalised");
  const loanOfficers = db2.staff.filter((s) => s.isLoanOfficer && s.status === "active");
  const activeClients = db2.clients.filter((c) => c.status === "active" || c.status === "closed");
  let loanId = 0;
  const makeLoan = (client, disbursedAgoDays, forcedStatus) => {
    var _a2, _b2;
    loanId++;
    const product = pick(db2.loanProducts);
    const principal = round2(r(product.principalMin, product.principalMax) / 10) * 10;
    const interestRate = round2(r(product.interestRateMin, product.interestRateMax) * 10) / 10;
    const term = ri(product.termMin, product.termMax);
    const periods = Math.max(2, Math.round(term / product.repayEvery));
    const officer = (_a2 = loanOfficers.find((s) => s.id === client.staffId)) != null ? _a2 : pick(loanOfficers);
    const submittedDate = disbursedAgoDays === null ? daysAgo(ri(1, 25)) : daysAgo(disbursedAgoDays + ri(7, 20));
    const loan = {
      id: loanId,
      accountNo: "LN-" + String(3e5 + loanId),
      clientId: client.id,
      groupId: (_b2 = client.groupIds[0]) != null ? _b2 : null,
      productId: product.id,
      officeId: client.officeId,
      staffId: officer.id,
      status: forcedStatus != null ? forcedStatus : "submitted",
      purpose: pick(PURPOSES),
      principal,
      interestRate,
      term,
      termFrequency: product.termFrequency,
      repayEvery: product.repayEvery,
      repayFrequency: product.repayFrequency,
      submittedDate,
      approvedDate: null,
      disbursedDate: null,
      closedDate: null,
      expectedMaturity: null,
      schedule: [],
      transactions: [],
      paidPrincipal: 0,
      paidInterest: 0,
      paidFees: 0,
      outstanding: principal,
      overdueAmount: 0,
      collateral: product.shortName === "GEL" ? "Group cross-guarantee" : pick(COLLATERAL),
      guarantor: rnd() < 0.5 ? `${pick([...MALE, ...FEMALE])} ${pick(SURNAMES)} (${pick(["Spouse", "Sibling", "Business partner"])})` : "\u2014"
    };
    if (forcedStatus === "submitted" || disbursedAgoDays === null) {
      loan.status = "submitted";
      loan.schedule = buildSchedule(principal, interestRate, periods, product.repayFrequency, daysAhead(14), product.graceOnPrincipal);
      return loan;
    }
    if (forcedStatus === "rejected") {
      loan.status = "rejected";
      loan.approvedDate = null;
      loan.rejectedDate = daysAgo(disbursedAgoDays + ri(3, 6));
      loan.schedule = buildSchedule(principal, interestRate, periods, product.repayFrequency, daysAgo(ri(1, 10)), product.graceOnPrincipal);
      return loan;
    }
    if (forcedStatus === "approved") {
      loan.status = "approved";
      loan.approvedDate = daysAgo(ri(1, 6));
      loan.schedule = buildSchedule(principal, interestRate, periods, product.repayFrequency, daysAhead(10), product.graceOnPrincipal);
      loan.expectedMaturity = loan.schedule[loan.schedule.length - 1].dueDate;
      return loan;
    }
    const disbursedDate = daysAgo(disbursedAgoDays);
    loan.approvedDate = daysAgo(disbursedAgoDays + ri(2, 5));
    loan.disbursedDate = disbursedDate;
    loan.schedule = buildSchedule(principal, interestRate, periods, product.repayFrequency, disbursedDate, product.graceOnPrincipal);
    loan.expectedMaturity = loan.schedule[loan.schedule.length - 1].dueDate;
    loan.transactions.push({
      id: nextTxnId(),
      date: disbursedDate,
      type: "disbursement",
      amount: principal,
      principal,
      interest: 0,
      fees: 0,
      paymentType: "Cash",
      note: "Principal disbursed to client"
    });
    postPair(disbursedDate, "LOAN_PORTFOLIO", "CASH", principal, `Disbursement ${loan.accountNo}`, loan.officeId);
    const procFee = round2(principal * 0.02);
    postPair(disbursedDate, "CASH", "FEE_INCOME", procFee, `Processing fee ${loan.accountNo}`, loan.officeId);
    const t = todayISO();
    const fullyMatured = loan.expectedMaturity < t;
    if (forcedStatus === "writtenoff") {
      let guard = 0;
      for (const e of loan.schedule) {
        if (guard >= ri(2, 5)) break;
        if (e.dueDate < t && rnd() < 0.85) {
          const payDate = e.dueDate;
          applyPayment(loan, e.totalDue, payDate, pick(PAYMENT_TYPES).name, "Installment");
          postPair(payDate, "CASH", "LOAN_PORTFOLIO", e.principalDue, `Repayment ${loan.accountNo}`, loan.officeId);
          postPair(payDate, "CASH", "INTEREST_INCOME", e.interestDue, `Interest ${loan.accountNo}`, loan.officeId);
        }
        guard++;
      }
      recomputeLoan(loan);
      loan.status = "writtenoff";
      loan.writtenOffDate = daysAgo(ri(20, 120));
      loan.transactions.push({ id: nextTxnId(), date: loan.writtenOffDate, type: "writeoff", amount: loan.outstanding, principal: loan.outstanding, interest: 0, fees: 0, paymentType: "\u2014", note: "Written off per credit policy" });
      postPair(loan.writtenOffDate, "WRITTEN_OFF", "LOAN_PORTFOLIO", loan.outstanding, `Write-off ${loan.accountNo}`, loan.officeId);
      loan.outstanding = 0;
      loan.overdueAmount = 0;
      return loan;
    }
    for (const e of loan.schedule) {
      if (e.dueDate >= t) break;
      const roll = rnd();
      if (roll < 0.82 || fullyMatured && rnd() < 0.9) {
        const dueAgo = Math.max(0, Math.round((Date.now() - (/* @__PURE__ */ new Date(e.dueDate + "T12:00:00Z")).getTime()) / DAY));
        const payDate = daysAgo(Math.max(0, dueAgo + ri(-3, 2)));
        applyPayment(loan, e.totalDue, payDate < t ? payDate : t, pick(PAYMENT_TYPES).name, "Installment");
        postPair(e.dueDate, "CASH", "LOAN_PORTFOLIO", e.principalDue, `Repayment ${loan.accountNo}`, loan.officeId);
        postPair(e.dueDate, "CASH", "INTEREST_INCOME", e.interestDue, `Interest ${loan.accountNo}`, loan.officeId);
      } else if (roll < 0.92) {
        const part = round2(e.totalDue * r(0.4, 0.85));
        applyPayment(loan, part, e.dueDate, pick(PAYMENT_TYPES).name, "Partial installment");
        postPair(e.dueDate, "CASH", "LOAN_PORTFOLIO", part, `Partial repayment ${loan.accountNo}`, loan.officeId);
      }
    }
    recomputeLoan(loan);
    if (fullyMatured && loan.outstanding <= 0.01) {
      loan.status = "closed";
      loan.closedDate = loan.expectedMaturity;
    } else if (fullyMatured && rnd() < 0.5 && loan.overdueAmount > 0) {
      const settleDate = daysAgo(ri(20, 200));
      applyPayment(loan, loan.outstanding, settleDate, "Cash", "Final settlement");
      loan.status = "closed";
      loan.closedDate = settleDate;
    } else {
      loan.status = "active";
    }
    return loan;
  };
  for (let i = 0; i < 185; i++) {
    const client = activeClients[i % activeClients.length];
    const roll = rnd();
    if (roll < 0.08) db2.loans.push(makeLoan(client, null));
    else if (roll < 0.15) db2.loans.push(makeLoan(client, null, "rejected"));
    else if (roll < 0.2) {
      const l = makeLoan(client, ri(3, 14), "approved");
      db2.loans.push(l);
    } else if (roll < 0.24) db2.loans.push(makeLoan(client, ri(300, 700), "writtenoff"));
    else db2.loans.push(makeLoan(client, ri(20, 600)));
  }
  db2.counters.loans = loanId;
  let savId = 0;
  for (let i = 0; i < 210; i++) {
    const client = db2.clients[ri(0, db2.clients.length - 1)];
    if (client.status === "pending" && rnd() < 0.5) continue;
    const product = pick(db2.savingsProducts);
    savId++;
    const submittedDate = daysAgo(ri(10, 1e3));
    const acc = {
      id: savId,
      accountNo: "SV-" + String(4e5 + savId),
      clientId: client.id,
      productId: product.id,
      officeId: client.officeId,
      staffId: (_b = client.staffId) != null ? _b : loanOfficers[0].id,
      status: "submitted",
      submittedDate,
      approvedDate: null,
      activatedDate: null,
      closedDate: null,
      interestRate: product.interestRate,
      balance: 0,
      totalDeposits: 0,
      totalWithdrawals: 0,
      transactions: []
    };
    const roll = rnd();
    if (roll < 0.08) {
      db2.savings.push(acc);
      continue;
    }
    acc.status = "approved";
    acc.approvedDate = daysAgo(Math.max(2, Math.round((Date.now() - new Date(submittedDate).getTime()) / DAY) - ri(1, 4)));
    if (roll < 0.14) {
      db2.savings.push(acc);
      continue;
    }
    const activatedDate = daysAgo(Math.max(3, Math.round((Date.now() - new Date(acc.approvedDate).getTime()) / DAY) - ri(0, 3)));
    acc.activatedDate = activatedDate;
    acc.status = "active";
    const openingBal = product.minOpeningBalance + ri(0, 20) * 10;
    let bal = openingBal;
    let txId = 0;
    const pushTxn = (type, amount, date, pay, note) => {
      txId++;
      if (type === "deposit" || type === "interest") bal = round2(bal + amount);
      else bal = round2(bal - amount);
      acc.transactions.push({ id: txId, date, type, amount, balanceAfter: bal, paymentType: pay, note });
      if (type === "deposit") {
        acc.totalDeposits = round2(acc.totalDeposits + amount);
        postPair(date, "CASH", "SAVINGS_CONTROL", amount, `Deposit ${acc.accountNo}`, acc.officeId);
      }
      if (type === "withdrawal") {
        acc.totalWithdrawals = round2(acc.totalWithdrawals + amount);
        postPair(date, "SAVINGS_CONTROL", "CASH", amount, `Withdrawal ${acc.accountNo}`, acc.officeId);
      }
      if (type === "interest") {
        postPair(date, "DEPOSIT_INTEREST", "INTEREST_PAYABLE", amount, `Interest accrual ${acc.accountNo}`, acc.officeId);
      }
      if (type === "fee") {
        postPair(date, "CASH", "FEE_INCOME", amount, `Ledger fee ${acc.accountNo}`, acc.officeId);
      }
    };
    pushTxn("deposit", openingBal, activatedDate, pick(PAYMENT_TYPES).name, "Opening deposit");
    const months = Math.floor((Date.now() - new Date(activatedDate).getTime()) / DAY / 30);
    let lastActive = activatedDate;
    for (let m = 1; m <= months; m++) {
      const date = daysAgo(Math.max(0, months - m) * 30 + ri(0, 20));
      if (date < activatedDate) continue;
      const dormant = rnd() < 0.06 && m > months - 8;
      if (dormant) break;
      const deposits = ri(1, 3);
      for (let d = 0; d < deposits; d++) {
        const amt = round2(r(20, product.type === "current" ? 3e3 : 800) / 5) * 5;
        pushTxn("deposit", amt, date, pick(PAYMENT_TYPES).name);
      }
      if (bal > 100 && rnd() < 0.7 && product.type !== "fixed") {
        const amt = round2(Math.min(bal * r(0.1, 0.6), product.type === "current" ? 2500 : 600) / 5) * 5;
        if (amt >= 5) pushTxn("withdrawal", amt, date, pick(PAYMENT_TYPES).name);
      }
      if (m % 3 === 0 && product.interestRate > 0 && bal > 0) {
        pushTxn("interest", round2(bal * (product.interestRate / 100) / 4), date, "\u2014", "Quarterly interest");
      }
      if (m % 1 === 0 && product.withdrawalFee > 0 && acc.transactions.some((t) => t.type === "withdrawal")) {
        pushTxn("fee", product.withdrawalFee, date, "\u2014", "Monthly ledger fee");
      }
      lastActive = date;
    }
    acc.balance = bal;
    if (roll > 0.96 && bal > 0) {
      pushTxn("withdrawal", round2(bal), todayISO(), "Cash", "Account closure");
      acc.balance = 0;
      acc.status = "closed";
      acc.closedDate = todayISO();
    } else if ((Date.now() - new Date(lastActive).getTime()) / DAY > 240) {
      acc.status = "dormant";
    } else {
      acc.status = "active";
    }
    db2.savings.push(acc);
  }
  db2.counters.savings = savId;
  for (let m = 12; m >= 1; m--) {
    const base = daysAgo(m * 30 + ri(0, 20));
    postPair(base, "STAFF_COSTS", "CASH", round2(r(38e3, 52e3)), "Monthly payroll");
    postPair(base, "RENT_UTILITIES", "CASH", round2(r(6e3, 9e3)), "Rent & utilities");
    if (m % 2 === 0) postPair(base, "ADMIN", "CASH", round2(r(1500, 3500)), "Administration & logistics");
    if (m % 3 === 0) postPair(base, "LOAN_LOSS_EXPENSE", "LOAN_PORTFOLIO", round2(r(4e3, 12e3)), "Quarterly provisioning charge");
  }
  db2.journals = ledgers.map((j, i) => ({ ...j, id: i + 1 }));
  let closureId = 0;
  for (let m = 2; m <= 13; m++) {
    closureId++;
    db2.closures.push({
      id: closureId,
      officeId: 1,
      closingDate: daysAgo(m * 30 - 28),
      createdDate: daysAgo(m * 30 - 27),
      comments: "Month-end books closed and reconciled.",
      status: "closed"
    });
  }
  const holidays = [
    { id: 1, name: "Independence Day", description: "National holiday \u2014 branches closed", fromDate: "2026-03-06", toDate: "2026-03-06", officeId: 1, status: "active" },
    { id: 2, name: "Eid al-Fitr", description: "Muslim festive holiday", fromDate: "2026-03-20", toDate: "2026-03-21", officeId: 1, status: "active" },
    { id: 3, name: "Founders\u2019 Day", description: "Founders\u2019 Day public holiday", fromDate: "2026-08-04", toDate: "2026-08-04", officeId: 1, status: "active" },
    { id: 4, name: "Farmers\u2019 Day", description: "Farmers\u2019 Day \u2014 shortened hours", fromDate: "2026-12-04", toDate: "2026-12-04", officeId: 1, status: "active" }
  ];
  db2.holidays = holidays;
  const pendingLoans = db2.loans.filter((l) => l.status === "submitted").slice(0, 4);
  const pendingSavings = db2.savings.filter((s) => s.status === "submitted").slice(0, 3);
  const pendingClients = db2.clients.filter((c) => c.status === "pending").slice(0, 2);
  let taskId = 0;
  const maker = db2.users[2];
  const mkTask = (entityType, action, entityId, label, days, amount) => {
    taskId++;
    return {
      id: taskId,
      createdDate: daysAgo(days),
      entityType,
      action,
      entityId,
      entityLabel: label,
      makerId: maker.id,
      makerName: `${maker.firstname} ${maker.lastname}`,
      status: "pending",
      checkerId: null,
      checkerName: null,
      checkedDate: null,
      note: "Awaiting checker approval",
      amount
    };
  };
  pendingLoans.forEach((l, i) => {
    var _a2;
    return db2.tasks.push(mkTask("LOAN", "Loan Approval", l.id, `${l.accountNo} \u2014 ${(_a2 = db2.clients.find((c) => c.id === l.clientId)) == null ? void 0 : _a2.displayName}`, i + 1, l.principal));
  });
  pendingSavings.forEach((s, i) => {
    var _a2;
    return db2.tasks.push(mkTask("SAVINGS", "Savings Approval", s.id, `${s.accountNo} \u2014 ${(_a2 = db2.clients.find((c) => c.id === s.clientId)) == null ? void 0 : _a2.displayName}`, i + 2));
  });
  pendingClients.forEach((c, i) => db2.tasks.push(mkTask("CLIENT", "Client Activation", c.id, `${c.accountNo} \u2014 ${c.displayName}`, i + 1)));
  db2.tasks.push(
    { id: ++taskId, createdDate: daysAgo(9), entityType: "LOAN", action: "Loan Disbursal", entityId: db2.loans.find((l) => l.status === "active").id, entityLabel: "LN-300014 \u2014 Yaa Darko", makerId: 3, makerName: "Esi Sarpong", status: "approved", checkerId: 1, checkerName: "Adjoa Mensah", checkedDate: daysAgo(8), note: "Verified collateral and KYC", amount: 4500 },
    { id: ++taskId, createdDate: daysAgo(12), entityType: "JOURNAL", action: "Manual Journal Entry", entityId: 0, entityLabel: "JE \u2014 stationery purchase (GH\u20B5 1,240)", makerId: 6, makerName: "Yaw Darko", status: "rejected", checkerId: 1, checkerName: "Adjoa Mensah", checkedDate: daysAgo(11), note: "Receipt not attached \u2014 rejected" }
  );
  let auditId = 0;
  const aud = (entity, action, entityId, name, days, user, result = "success", notes = "") => {
    var _a2, _b2, _c, _d, _e;
    auditId++;
    db2.audit.push({
      id: auditId,
      timestamp: daysAgo(days) + "T" + String(ri(8, 17)).padStart(2, "0") + ":" + String(ri(10, 59)).padStart(2, "0") + ":00Z",
      entity,
      action,
      entityId,
      entityName: name,
      userId: (_b2 = (_a2 = db2.users.find((u) => u.username === user)) == null ? void 0 : _a2.id) != null ? _b2 : 1,
      userName: ((_c = db2.users.find((u) => u.username === user)) == null ? void 0 : _c.firstname) + " " + ((_e = (_d = db2.users.find((u) => u.username === user)) == null ? void 0 : _d.lastname) != null ? _e : ""),
      officeId: ri(1, 6),
      result,
      notes
    });
  };
  for (let i = 0; i < 34; i++) {
    const kind = i % 6;
    const days = ri(0, 45);
    if (kind === 0) {
      const l = db2.loans[ri(0, db2.loans.length - 1)];
      aud("Loan", pick(["CREATE", "APPROVE", "DISBURSE", "REPAYMENT"]), l.id, l.accountNo, days, pick(["e.sarpong", "f.ankrah", "k.owusu"]));
    } else if (kind === 1) {
      const c = db2.clients[ri(0, db2.clients.length - 1)];
      aud("Client", pick(["CREATE", "ACTIVATE", "UPDATE"]), c.id, c.displayName, days, pick(["e.sarpong", "f.ankrah", "a.appiah"]));
    } else if (kind === 2) {
      const s = db2.savings[ri(0, db2.savings.length - 1)];
      aud("Savings", pick(["DEPOSIT", "WITHDRAWAL", "APPROVE", "ACTIVATE"]), s.id, s.accountNo, days, pick(["a.appiah", "f.ankrah"]));
    } else if (kind === 3) {
      aud("Journal Entry", pick(["CREATE", "POST"]), ri(100, 400), "Manual JE", days, "y.darko");
    } else if (kind === 4) {
      aud("Checker Task", pick(["APPROVE", "REJECT"]), ri(1, 9), "Maker-checker task", days, "a.mensah");
    } else {
      aud("User", "LOGIN", 1, "Console sign-in", days, pick(["a.mensah", "k.owusu", "e.sarpong"]), rnd() < 0.1 ? "failure" : "success", rnd() < 0.1 ? "Invalid credentials" : "");
    }
  }
  db2.audit.sort((a, b) => a.timestamp < b.timestamp ? 1 : -1);
  db2.counters.audit = auditId;
  db2.counters.tasks = taskId;
  return db2;
}
function db() {
  if (!globalThis.__tlCoreBankDB) globalThis.__tlCoreBankDB = buildDB();
  return globalThis.__tlCoreBankDB;
}
function nextId(d, key) {
  var _a;
  d.counters[key] = ((_a = d.counters[key]) != null ? _a : 0) + 1;
  return d.counters[key];
}
function logAudit(d, entity, action, entityId, name, notes = "", result = "success") {
  const u = d.currentUser;
  d.audit.unshift({
    id: nextId(d, "audit"),
    timestamp: (/* @__PURE__ */ new Date()).toISOString().replace(/\.\d+Z$/, "Z"),
    entity,
    action,
    entityId,
    entityName: name,
    userId: u.id,
    userName: u.name,
    officeId: u.officeId,
    result,
    notes
  });
}

export { db as d, logAudit as l, todayISO as t };
//# sourceMappingURL=db.mjs.map
