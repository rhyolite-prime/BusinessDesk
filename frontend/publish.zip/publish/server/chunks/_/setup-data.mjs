const LEDGER_AMOUNT_SCALE = BigInt(1e6);
const LEDGER_RATE_SCALE = BigInt(1e10);
function normalizeWholePart(value) {
  const normalized = value.replace(/^0+/, "") || "0";
  return normalized.length <= 14 ? normalized : null;
}
function parseLedgerAmount(value, blankAsZero = false) {
  const amount = value.trim();
  if (!amount && blankAsZero) return BigInt(0);
  if (amount.length > 64 || !/^\d+(\.\d{1,6})?$/.test(amount)) return null;
  const [whole = "0", fraction = ""] = amount.split(".");
  const normalizedWhole = normalizeWholePart(whole);
  if (normalizedWhole === null) return null;
  return BigInt(normalizedWhole) * LEDGER_AMOUNT_SCALE + BigInt(fraction.padEnd(6, "0"));
}
function parseLedgerRate(value) {
  const rate = value.trim();
  if (rate.length > 64 || !/^\d+(\.\d{1,10})?$/.test(rate)) return null;
  const [whole = "0", fraction = ""] = rate.split(".");
  const normalizedWhole = normalizeWholePart(whole);
  if (normalizedWhole === null) return null;
  return BigInt(normalizedWhole) * LEDGER_RATE_SCALE + BigInt(fraction.padEnd(10, "0"));
}
function formatLedgerAmount(units) {
  const whole = units / LEDGER_AMOUNT_SCALE;
  const fraction = String(units % LEDGER_AMOUNT_SCALE).padStart(6, "0");
  return `${whole}.${fraction}`;
}
function convertLedgerAmount(amountUnits, rateUnits) {
  return (amountUnits * rateUnits + LEDGER_RATE_SCALE / BigInt(2)) / LEDGER_RATE_SCALE;
}
function percentageOfLedgerAmount(amountUnits, percentageUnits) {
  const divisor = BigInt(100) * LEDGER_AMOUNT_SCALE;
  return (amountUnits * percentageUnits + divisor / BigInt(2)) / divisor;
}

const ledgerSetupIds = {
  bankControl: "control-bank-accounts"};
const ledgerCurrencyOptions = [
  { code: "GHS", name: "Ghana cedi" },
  { code: "USD", name: "US dollar" },
  { code: "EUR", name: "Euro" },
  { code: "GBP", name: "Pound sterling" }
];

export { LEDGER_RATE_SCALE as L, parseLedgerAmount as a, ledgerSetupIds as b, convertLedgerAmount as c, LEDGER_AMOUNT_SCALE as d, percentageOfLedgerAmount as e, formatLedgerAmount as f, ledgerCurrencyOptions as l, parseLedgerRate as p };
//# sourceMappingURL=setup-data.mjs.map
