import { u as useRuntimeConfig, c as createError, a as getHeader } from '../nitro/nitro.mjs';
import { r as requireBusinessDeskSession } from './auth.mjs';

async function getLedgerResource(event, resource, query, demo) {
  const session = await requireBusinessDeskSession(event);
  const config = useRuntimeConfig(event);
  const baseUrl = String(config.ledgerApiBaseUrl || "").replace(/\/$/, "");
  if (baseUrl) {
    if (session.demo || !session.accessToken) {
      throw createError({ statusCode: 403, statusMessage: "Demo sign-in cannot access a configured ledger service." });
    }
    return await $fetch(`${baseUrl}/api/v1/ledger/${resource}`, {
      query,
      headers: {
        authorization: `Bearer ${session.accessToken}`,
        "x-request-id": getHeader(event, "x-request-id") || crypto.randomUUID()
      }
    });
  }
  if (config.public.demoMode) {
    return demo();
  }
  throw createError({
    statusCode: 503,
    statusMessage: "Ledger API is not configured",
    data: { code: "LEDGER_API_UNAVAILABLE" }
  });
}

export { getLedgerResource as g };
//# sourceMappingURL=ledger-api.mjs.map
