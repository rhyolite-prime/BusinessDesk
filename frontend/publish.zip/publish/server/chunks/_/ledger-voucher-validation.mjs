import { c as createError } from '../nitro/nitro.mjs';
import { b as ledgerSetupIds, l as ledgerCurrencyOptions, p as parseLedgerRate, L as LEDGER_RATE_SCALE, a as parseLedgerAmount, c as convertLedgerAmount, f as formatLedgerAmount, d as LEDGER_AMOUNT_SCALE, e as percentageOfLedgerAmount } from './setup-data.mjs';
import { l as ledgerOrganizationalUnits } from './organization-data.mjs';
import { d as demoAccounts } from './auth.mjs';

const voucherTypeMetadata = [
  {
    value: "supplier-payment",
    label: "Supplier payment voucher",
    shortLabel: "Supplier payment",
    payeeLabel: "Supplier / payee",
    description: "Record a payment to a supplier and allocate it across ledger accounts.",
    prefix: "SPV",
    accountDirection: "debit",
    dateLabel: "Payment date"
  },
  {
    value: "employee-payment",
    label: "Employee payment voucher",
    shortLabel: "Employee payment",
    payeeLabel: "Employee / payee",
    description: "Record staff reimbursements, advances, and other employee payments.",
    prefix: "EPV",
    accountDirection: "debit",
    dateLabel: "Payment date"
  },
  {
    value: "customer-receipt",
    label: "Customer receipt voucher",
    shortLabel: "Customer receipt",
    payeeLabel: "Customer",
    description: "Record cash or bank receipts from customers against ledger accounts.",
    prefix: "CRV",
    accountDirection: "credit",
    dateLabel: "Receipt date"
  }
];
const voucherPayees = {
  "supplier-payment": [
    { id: "supplier-adom-trading", name: "Adom Trading Company", code: "SUP-0001" },
    { id: "supplier-bluewave", name: "Bluewave Office Supplies", code: "SUP-0002" },
    { id: "supplier-golden-coast", name: "Golden Coast Logistics", code: "SUP-0003" },
    { id: "supplier-kasoa-tech", name: "Kasoa Technologies Ltd.", code: "SUP-0004" }
  ],
  "employee-payment": [
    { id: "employee-akua-mensah", name: "Akua Mensah", code: "EMP-0012" },
    { id: "employee-kwame-osei", name: "Kwame Osei", code: "EMP-0019" },
    { id: "employee-efua-boateng", name: "Efua Boateng", code: "EMP-0026" },
    { id: "employee-kofi-agyeman", name: "Kofi Agyeman", code: "EMP-0031" }
  ],
  "customer-receipt": [
    { id: "customer-akua-consulting", name: "Akua Consulting Co.", code: "CUS-0007" },
    { id: "customer-northstar", name: "Northstar Services Ltd.", code: "CUS-0011" },
    { id: "customer-heritage", name: "Heritage Property Group", code: "CUS-0018" },
    { id: "customer-kofi-enterprises", name: "Kofi Enterprises", code: "CUS-0023" }
  ]
};
const voucherPaymentMethods = ["Cash", "Cheque", "Bank transfer", "Mobile money"];
function isLedgerVoucherType(value) {
  return voucherTypeMetadata.some((type) => type.value === value);
}
function payeesForVoucherType(type) {
  return voucherPayees[type];
}

function isRealDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = /* @__PURE__ */ new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function requiredText(value, label, maximum) {
  const text = String(value != null ? value : "").trim();
  if (!text || text.length > maximum) {
    throw createError({ statusCode: 400, statusMessage: `${label} is required and must not exceed ${maximum} characters.` });
  }
  return text;
}
function normalizeVoucherInput(body) {
  var _a, _b, _c, _d, _e, _f;
  if (!isLedgerVoucherType(body.type)) {
    throw createError({ statusCode: 400, statusMessage: "Select a supported voucher type." });
  }
  const type = body.type;
  const payeeId = requiredText(body.payeeId, "Payee", 80);
  const payee = payeesForVoucherType(type).find((item) => item.id === payeeId);
  if (!payee) throw createError({ statusCode: 400, statusMessage: "Select a valid payee for this voucher type." });
  const entryDate = requiredText(body.entryDate, "Entry date", 10);
  if (!isRealDate(entryDate)) throw createError({ statusCode: 400, statusMessage: "Entry date must be a real calendar date in YYYY-MM-DD format." });
  const isReceipt = type === "customer-receipt";
  const effectiveDate = requiredText(isReceipt ? body.receiptDate : body.paymentDate, isReceipt ? "Receipt date" : "Payment date", 10);
  if (!isRealDate(effectiveDate)) throw createError({ statusCode: 400, statusMessage: `${isReceipt ? "Receipt" : "Payment"} date must be a real calendar date in YYYY-MM-DD format.` });
  const bankAccountId = requiredText(body.bankAccountId, "Bank account", 80);
  const bankAccountName = requiredText(body.bankAccountName, "Bank account name", 160);
  const bankGlAccountId = requiredText(body.bankGlAccountId, "Bank G/L account", 80);
  const bankGlAccount = demoAccounts.find((account) => account.id === bankGlAccountId && account.status === "Active");
  if (!bankGlAccount || bankGlAccount.accountHeaderId !== ledgerSetupIds.bankControl) {
    throw createError({ statusCode: 400, statusMessage: "Select an active chart account linked to the bank-account control." });
  }
  const mode = body.mode;
  if (!mode || !voucherPaymentMethods.includes(mode)) throw createError({ statusCode: 400, statusMessage: "Select a supported payment or receipt method." });
  const chequeNumber = String((_a = body.chequeNumber) != null ? _a : "").trim();
  if (chequeNumber.length > 80 || mode === "Cheque" && !chequeNumber) {
    throw createError({ statusCode: 400, statusMessage: "Enter a cheque number when the payment method is cheque." });
  }
  const currencyCode = String((_b = body.currencyCode) != null ? _b : "").trim().toUpperCase();
  if (!ledgerCurrencyOptions.some((currency) => currency.code === currencyCode)) {
    throw createError({ statusCode: 400, statusMessage: "Select a supported transaction currency." });
  }
  const multiCurrency = Boolean(body.multiCurrency);
  if (currencyCode !== "GHS" && !multiCurrency) {
    throw createError({ statusCode: 400, statusMessage: "Enable multi-currency for a transaction currency other than GHS." });
  }
  const exchangeRate = String((_c = body.exchangeRate) != null ? _c : currencyCode === "GHS" ? "1" : "").trim();
  const exchangeRateUnits = parseLedgerRate(exchangeRate);
  if (exchangeRateUnits === null || exchangeRateUnits <= BigInt(0)) {
    throw createError({ statusCode: 400, statusMessage: "Exchange rate must be a positive decimal with at most 10 decimal places." });
  }
  if (currencyCode === "GHS" && exchangeRateUnits !== LEDGER_RATE_SCALE) {
    throw createError({ statusCode: 400, statusMessage: "GHS vouchers must use an exchange rate of 1." });
  }
  const description = String((_d = body.description) != null ? _d : "").trim();
  if (description.length > 300) throw createError({ statusCode: 400, statusMessage: "Voucher description must not exceed 300 characters." });
  const linesInput = Array.isArray(body.lines) ? body.lines : [];
  if (linesInput.length < 1 || linesInput.length > 1e3) {
    throw createError({ statusCode: 400, statusMessage: "A voucher must contain between one and 1000 ledger lines." });
  }
  let totalUnits = BigInt(0);
  let foreignTotalUnits = BigInt(0);
  const lines = linesInput.map((line, index) => {
    var _a2, _b2, _c2, _d2, _e2, _f2, _g, _h;
    const accountId = String((_a2 = line == null ? void 0 : line.accountId) != null ? _a2 : "").trim();
    const account = demoAccounts.find((item) => item.id === accountId && item.status === "Active");
    if (!account) throw createError({ statusCode: 400, statusMessage: `Line ${index + 1}: select an active G/L account.` });
    if (account.id === bankGlAccountId) throw createError({ statusCode: 400, statusMessage: `Line ${index + 1}: choose a non-bank offset account.` });
    const invoiceNumber = String((_b2 = line == null ? void 0 : line.invoiceNumber) != null ? _b2 : "").trim();
    const referenceNumber = String((_c2 = line == null ? void 0 : line.referenceNumber) != null ? _c2 : "").trim();
    const lineDescription = String((_d2 = line == null ? void 0 : line.description) != null ? _d2 : "").trim();
    const organizationUnitId = String((_e2 = line == null ? void 0 : line.organizationUnitId) != null ? _e2 : "").trim();
    if (invoiceNumber.length > 80 || referenceNumber.length > 80 || lineDescription.length > 300) {
      throw createError({ statusCode: 400, statusMessage: `Line ${index + 1}: invoice, reference, or description is too long.` });
    }
    const organizationUnit = organizationUnitId ? ledgerOrganizationalUnits.find((unit) => unit.id === organizationUnitId) : void 0;
    if (organizationUnitId && !organizationUnit) {
      throw createError({ statusCode: 400, statusMessage: `Line ${index + 1}: select a valid organizational unit.` });
    }
    const localInput = parseLedgerAmount(String((_f2 = line == null ? void 0 : line.localAmount) != null ? _f2 : ""), true);
    const foreignInput = parseLedgerAmount(String((_g = line == null ? void 0 : line.foreignAmount) != null ? _g : ""), true);
    if (localInput === null || foreignInput === null) {
      throw createError({ statusCode: 400, statusMessage: `Line ${index + 1}: enter valid amounts with up to six decimal places.` });
    }
    let localUnits = localInput;
    let foreignUnits = foreignInput;
    if (multiCurrency) {
      if (foreignUnits <= BigInt(0)) throw createError({ statusCode: 400, statusMessage: `Line ${index + 1}: foreign amount must be greater than zero.` });
      localUnits = convertLedgerAmount(foreignUnits, exchangeRateUnits);
      if (localUnits <= BigInt(0)) throw createError({ statusCode: 400, statusMessage: `Line ${index + 1}: converted local amount must be greater than zero.` });
      foreignTotalUnits += foreignUnits;
    } else {
      if (localUnits <= BigInt(0)) throw createError({ statusCode: 400, statusMessage: `Line ${index + 1}: local amount must be greater than zero.` });
      foreignUnits = BigInt(0);
    }
    totalUnits += localUnits;
    return {
      id: `demo-${crypto.randomUUID()}`,
      invoiceNumber,
      referenceNumber,
      accountId: account.id,
      accountNumber: account.accountNumber,
      accountName: account.name,
      description: lineDescription,
      organizationUnitId,
      organizationUnitName: (_h = organizationUnit == null ? void 0 : organizationUnit.path) != null ? _h : "",
      localAmount: formatLedgerAmount(localUnits),
      foreignAmount: formatLedgerAmount(foreignUnits),
      isWithhold: Boolean(line == null ? void 0 : line.isWithhold)
    };
  });
  const withholdingBaseUnits = lines.reduce((sum, line) => {
    var _a2;
    if (!line.isWithhold) return sum;
    return sum + ((_a2 = parseLedgerAmount(line.localAmount, true)) != null ? _a2 : BigInt(0));
  }, BigInt(0));
  const retentionsInput = Array.isArray(body.retentions) ? body.retentions : [];
  if (isReceipt && retentionsInput.length) {
    throw createError({ statusCode: 400, statusMessage: "Customer receipt vouchers do not support payment retentions." });
  }
  if (retentionsInput.length > 100) throw createError({ statusCode: 400, statusMessage: "A voucher cannot contain more than 100 retention lines." });
  let retentionsTotalUnits = BigInt(0);
  const retentions = retentionsInput.map((retention, index) => {
    var _a2, _b2;
    const accountId = String((_a2 = retention == null ? void 0 : retention.accountId) != null ? _a2 : "").trim();
    const account = demoAccounts.find((item) => item.id === accountId && item.status === "Active");
    if (!account) throw createError({ statusCode: 400, statusMessage: `Retention ${index + 1}: select an active credit G/L account.` });
    const retentionDescription = requiredText(retention == null ? void 0 : retention.description, `Retention ${index + 1} description`, 160);
    const valueText = String((_b2 = retention == null ? void 0 : retention.value) != null ? _b2 : "").trim();
    const valueUnits = parseLedgerAmount(valueText);
    if (valueUnits === null || valueUnits <= BigInt(0)) {
      throw createError({ statusCode: 400, statusMessage: `Retention ${index + 1}: enter a positive amount or percentage.` });
    }
    const isPercentage = Boolean(retention == null ? void 0 : retention.isPercentage);
    if (isPercentage && valueUnits > BigInt(100) * LEDGER_AMOUNT_SCALE) {
      throw createError({ statusCode: 400, statusMessage: `Retention ${index + 1}: percentage cannot exceed 100%.` });
    }
    if (isPercentage && withholdingBaseUnits <= BigInt(0)) {
      throw createError({ statusCode: 400, statusMessage: `Retention ${index + 1}: mark at least one voucher line as withholdable.` });
    }
    const amountUnits = isPercentage ? percentageOfLedgerAmount(withholdingBaseUnits, valueUnits) : valueUnits;
    if (amountUnits <= BigInt(0)) throw createError({ statusCode: 400, statusMessage: `Retention ${index + 1}: calculated retention must be greater than zero.` });
    retentionsTotalUnits += amountUnits;
    return {
      id: `demo-${crypto.randomUUID()}`,
      accountId: account.id,
      accountNumber: account.accountNumber,
      accountName: account.name,
      description: retentionDescription,
      value: formatLedgerAmount(valueUnits),
      isPercentage,
      amount: formatLedgerAmount(amountUnits)
    };
  });
  if (retentionsTotalUnits > totalUnits) {
    throw createError({ statusCode: 400, statusMessage: "Total retentions cannot be greater than the voucher amount." });
  }
  const paymentDate = isReceipt ? void 0 : effectiveDate;
  const receiptDate = isReceipt ? effectiveDate : void 0;
  const payeeName = (_f = (_e = payeesForVoucherType(type).find((item) => item.id === payeeId)) == null ? void 0 : _e.name) != null ? _f : "";
  return {
    type,
    payeeId,
    payeeName,
    entryDate,
    ...paymentDate ? { paymentDate } : {},
    ...receiptDate ? { receiptDate } : {},
    bankAccountId,
    bankAccountName,
    bankGlAccountId,
    bankGlAccountName: `${bankGlAccount.accountNumber} \u2014 ${bankGlAccount.name}`,
    mode,
    currencyCode,
    exchangeRate: formatRate(exchangeRateUnits),
    multiCurrency,
    chequeNumber,
    description,
    totalAmount: formatLedgerAmount(totalUnits),
    foreignTotal: formatLedgerAmount(foreignTotalUnits),
    retentionsTotal: formatLedgerAmount(retentionsTotalUnits),
    netAmount: formatLedgerAmount(totalUnits - retentionsTotalUnits),
    lines,
    retentions
  };
}
function formatRate(rateUnits) {
  const whole = rateUnits / LEDGER_RATE_SCALE;
  const fraction = String(rateUnits % LEDGER_RATE_SCALE).padStart(10, "0");
  return `${whole}.${fraction}`;
}

export { normalizeVoucherInput as n };
//# sourceMappingURL=ledger-voucher-validation.mjs.map
