const interopDefault = r => r.default || r || [];
const styles = {
  "pages/ledger/imprests/payroll-loans.vue": () => import('../build/payroll-loans-styles.CSbsxvai.mjs').then(interopDefault),
  "pages/ledger/imprests/index.vue": () => import('../build/index-styles.zm1jr14U.mjs').then(interopDefault),
  "../node_modules/.pnpm/nuxt@4.6.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_6a967b8ddf2131460526d2fa027396a7/node_modules/nuxt/dist/app/components/error-500.vue": () => import('../build/error-500-styles.TDZFSATp.mjs').then(interopDefault),
  "../node_modules/.pnpm/nuxt@4.6.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_6a967b8ddf2131460526d2fa027396a7/node_modules/nuxt/dist/app/components/error-404.vue": () => import('../build/error-404-styles.-E8eWxK1.mjs').then(interopDefault)
};

const inlinedCSS = {"error-404.DAauDMom.css":[["../node_modules/.pnpm/nuxt@4.6.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_6a967b8ddf2131460526d2fa027396a7/node_modules/nuxt/dist/app/components/error-404.vue"]],"error-500.czYGpab0.css":[["../node_modules/.pnpm/nuxt@4.6.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_6a967b8ddf2131460526d2fa027396a7/node_modules/nuxt/dist/app/components/error-500.vue"]],"imprests.CsFVhHgX.css":[["pages/ledger/imprests/index.vue"]],"payroll-loans.Cjm7n5N4.css":[["pages/ledger/imprests/payroll-loans.vue"]]};

export { styles as default, inlinedCSS };
//# sourceMappingURL=styles.mjs.map
